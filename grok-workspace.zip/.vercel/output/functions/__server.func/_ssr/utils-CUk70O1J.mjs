import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/utils-CUk70O1J.js
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function num(value) {
	if (typeof value === "number") return Number.isFinite(value) ? value : 0;
	if (typeof value === "string") {
		const n = Number(value);
		return Number.isFinite(n) ? n : 0;
	}
	return 0;
}
function brl(value) {
	return value.toLocaleString("pt-BR", {
		style: "currency",
		currency: "BRL"
	});
}
function pct(value) {
	return `${(value * 100).toLocaleString("pt-BR", { maximumFractionDigits: 1 })}%`;
}
function monthKey(date) {
	const d = typeof date === "string" ? /* @__PURE__ */ new Date(date + (date.length === 10 ? "T12:00:00" : "")) : date;
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}
function monthLabel(key, style = "short") {
	const [y, m] = key.split("-").map(Number);
	const month = new Date(y, (m || 1) - 1, 1).toLocaleDateString("pt-BR", { month: style === "long" ? "long" : "short" });
	return `${month.charAt(0).toUpperCase() + month.slice(1).replace(".", "")}/${y}`;
}
function currentMonthKey(now = /* @__PURE__ */ new Date()) {
	return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
}
function shiftMonth(key, delta) {
	const [y, m] = key.split("-").map(Number);
	const d = new Date(y, m - 1 + delta, 1);
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}
function uid(prefix = "id") {
	return `${prefix}_${crypto.randomUUID()}`;
}
//#endregion
export { monthLabel as a, shiftMonth as c, monthKey as i, uid as l, cn as n, num as o, currentMonthKey as r, pct as s, brl as t };
