import { c as shiftMonth, i as monthKey, l as uid, o as num, r as currentMonthKey } from "./utils-CUk70O1J.mjs";
import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { r as getSql } from "./db-84K_tst5.mjs";
import { t as authMiddleware } from "./middleware-CLo3ysqK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/finance-BbO5m4CA.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var CATEGORIES = [
	{
		key: "salario",
		name: "Salários",
		kind: "income",
		tone: "income",
		icon: "wallet"
	},
	{
		key: "aluguel",
		name: "Aluguel recebido",
		kind: "income",
		tone: "income",
		icon: "home"
	},
	{
		key: "extra",
		name: "Extra / 13º",
		kind: "income",
		tone: "income",
		icon: "spark"
	},
	{
		key: "saude",
		name: "Saúde",
		kind: "expense",
		tone: "chart-5",
		icon: "heart"
	},
	{
		key: "moradia",
		name: "Casa",
		kind: "expense",
		tone: "chart-2",
		icon: "home"
	},
	{
		key: "transporte",
		name: "Transporte",
		kind: "expense",
		tone: "chart-3",
		icon: "bus"
	},
	{
		key: "celular",
		name: "Celular",
		kind: "expense",
		tone: "chart-6",
		icon: "phone"
	},
	{
		key: "parcelado",
		name: "Parcelamentos",
		kind: "expense",
		tone: "chart-4",
		icon: "layers"
	},
	{
		key: "cartao",
		name: "Fatura cartão",
		kind: "expense",
		tone: "chart-4",
		icon: "card"
	},
	{
		key: "mercado",
		name: "Mercado",
		kind: "expense",
		tone: "chart-1",
		icon: "bag"
	},
	{
		key: "pessoal",
		name: "Pessoal",
		kind: "expense",
		tone: "chart-3",
		icon: "user"
	},
	{
		key: "emprestimo",
		name: "Empréstimo",
		kind: "expense",
		tone: "expense",
		icon: "landmark"
	},
	{
		key: "gerais",
		name: "Gerais",
		kind: "expense",
		tone: "muted",
		icon: "dots"
	}
];
var CARDS = [
	{
		key: "neon",
		name: "Neon Iasmim",
		holder: "Iasmim",
		brand: "Neon",
		limit: 2500,
		closing: 20,
		due: 27
	},
	{
		key: "ingrid",
		name: "Cartão Ingrid",
		holder: "Ingrid",
		brand: "Visa",
		limit: 2e3,
		closing: 20,
		due: 27
	},
	{
		key: "americanas",
		name: "Americanas",
		holder: "Casa",
		brand: "Americanas",
		limit: 800,
		closing: 25,
		due: 5
	},
	{
		key: "credicard",
		name: "Credicard",
		holder: "Casa",
		brand: "Credicard",
		limit: 1500,
		closing: 20,
		due: 10
	}
];
var TRANSACTIONS = [
	{
		date: "2026-06-05",
		desc: "Neon Fasomim",
		amount: 86,
		dir: "out",
		cat: "parcelado",
		card: "neon",
		inst: "1/3",
		status: "paid"
	},
	{
		date: "2026-06-10",
		desc: "Plano Cecília",
		amount: 216,
		dir: "out",
		cat: "saude",
		status: "paid"
	},
	{
		date: "2026-06-12",
		desc: "Água / Esgoto",
		amount: 230,
		dir: "out",
		cat: "moradia",
		status: "paid"
	},
	{
		date: "2026-06-15",
		desc: "Energia",
		amount: 95,
		dir: "out",
		cat: "moradia",
		status: "paid"
	},
	{
		date: "2026-06-20",
		desc: "Celular TIM",
		amount: 120,
		dir: "out",
		cat: "celular",
		status: "paid",
		notes: "Rafa e Gabriela"
	},
	{
		date: "2026-06-25",
		desc: "Plano NENA",
		amount: 288,
		dir: "out",
		cat: "saude",
		status: "paid"
	},
	{
		date: "2026-06-28",
		desc: "Internet Casa",
		amount: 135,
		dir: "out",
		cat: "moradia",
		status: "paid"
	},
	{
		date: "2026-06-30",
		desc: "Despesas gerais",
		amount: 1350,
		dir: "out",
		cat: "gerais",
		status: "paid"
	},
	{
		date: "2026-06-05",
		desc: "Apartamento Rafa",
		amount: 1475,
		dir: "in",
		cat: "aluguel",
		status: "received"
	},
	{
		date: "2026-06-07",
		desc: "Salário Rafa",
		amount: 1300,
		dir: "in",
		cat: "salario",
		status: "received"
	},
	{
		date: "2026-06-07",
		desc: "Salário Gabi",
		amount: 1500,
		dir: "in",
		cat: "salario",
		status: "received"
	},
	{
		date: "2026-06-10",
		desc: "Eliane Casa",
		amount: 250,
		dir: "in",
		cat: "extra",
		status: "received"
	},
	{
		date: "2026-07-05",
		desc: "Neon Fasomim",
		amount: 86,
		dir: "out",
		cat: "parcelado",
		card: "neon",
		inst: "2/3",
		status: "paid"
	},
	{
		date: "2026-07-05",
		desc: "Neon Iasmim",
		amount: 145,
		dir: "out",
		cat: "cartao",
		card: "neon",
		inst: "1/8",
		status: "paid"
	},
	{
		date: "2026-07-10",
		desc: "Plano Cecília",
		amount: 216,
		dir: "out",
		cat: "saude",
		status: "paid"
	},
	{
		date: "2026-07-12",
		desc: "Água / Esgoto",
		amount: 230,
		dir: "out",
		cat: "moradia",
		status: "paid"
	},
	{
		date: "2026-07-15",
		desc: "Energia",
		amount: 95,
		dir: "out",
		cat: "moradia",
		status: "paid"
	},
	{
		date: "2026-07-20",
		desc: "Celular TIM",
		amount: 120,
		dir: "out",
		cat: "celular",
		status: "paid"
	},
	{
		date: "2026-07-25",
		desc: "Plano NENA",
		amount: 288,
		dir: "out",
		cat: "saude",
		status: "paid"
	},
	{
		date: "2026-07-28",
		desc: "Internet Casa",
		amount: 135,
		dir: "out",
		cat: "moradia",
		status: "paid"
	},
	{
		date: "2026-07-30",
		desc: "Despesas gerais",
		amount: 1350,
		dir: "out",
		cat: "gerais",
		status: "paid"
	},
	{
		date: "2026-07-05",
		desc: "Apartamento Rafa",
		amount: 1475,
		dir: "in",
		cat: "aluguel",
		status: "received"
	},
	{
		date: "2026-07-07",
		desc: "Salário Rafa",
		amount: 1300,
		dir: "in",
		cat: "salario",
		status: "received"
	},
	{
		date: "2026-07-07",
		desc: "Salário Gabi",
		amount: 1500,
		dir: "in",
		cat: "salario",
		status: "received"
	},
	{
		date: "2026-07-10",
		desc: "Eliane Casa",
		amount: 250,
		dir: "in",
		cat: "extra",
		status: "received"
	},
	{
		date: "2026-08-20",
		desc: "Guarda-roupa",
		amount: 60,
		dir: "out",
		cat: "parcelado",
		card: "neon",
		inst: "3/12",
		status: "paid"
	},
	{
		date: "2026-08-20",
		desc: "Perfumes Boticário",
		amount: 143,
		dir: "out",
		cat: "pessoal",
		status: "paid",
		notes: "Última parcela"
	},
	{
		date: "2026-08-20",
		desc: "Plano Cecília",
		amount: 250,
		dir: "out",
		cat: "saude",
		status: "paid"
	},
	{
		date: "2026-08-20",
		desc: "Credicard",
		amount: 200,
		dir: "out",
		cat: "cartao",
		card: "credicard",
		status: "paid"
	},
	{
		date: "2026-08-20",
		desc: "Sofá",
		amount: 288,
		dir: "out",
		cat: "parcelado",
		card: "ingrid",
		inst: "4/6",
		status: "paid"
	},
	{
		date: "2026-08-31",
		desc: "Cartão Americanas",
		amount: 200,
		dir: "out",
		cat: "cartao",
		card: "americanas",
		status: "paid"
	},
	{
		date: "2026-08-20",
		desc: "Internet Casa",
		amount: 145,
		dir: "out",
		cat: "moradia",
		status: "paid"
	},
	{
		date: "2026-08-20",
		desc: "Transporte 20–31",
		amount: 131.2,
		dir: "out",
		cat: "transporte",
		status: "paid"
	},
	{
		date: "2026-08-28",
		desc: "Gasto avulso",
		amount: 250,
		dir: "out",
		cat: "gerais",
		status: "paid"
	},
	{
		date: "2026-08-31",
		desc: "Plano NENA",
		amount: 288,
		dir: "out",
		cat: "saude",
		status: "paid"
	},
	{
		date: "2026-08-31",
		desc: "Luz e água",
		amount: 200,
		dir: "out",
		cat: "moradia",
		status: "paid"
	},
	{
		date: "2026-08-31",
		desc: "Celular TIM",
		amount: 140,
		dir: "out",
		cat: "celular",
		status: "paid",
		notes: "Rafa e Gabriela"
	},
	{
		date: "2026-08-31",
		desc: "Gabriela",
		amount: 100,
		dir: "out",
		cat: "pessoal",
		status: "paid"
	},
	{
		date: "2026-08-28",
		desc: "Despesas gerais",
		amount: 400,
		dir: "out",
		cat: "gerais",
		status: "paid"
	},
	{
		date: "2026-08-05",
		desc: "Adiantamento Rafa e Gabi",
		amount: 2870,
		dir: "in",
		cat: "salario",
		status: "received"
	},
	{
		date: "2026-08-20",
		desc: "Salário Rafa e Gabi",
		amount: 2200,
		dir: "in",
		cat: "salario",
		status: "received"
	},
	{
		date: "2026-09-20",
		desc: "Guarda-roupa",
		amount: 60,
		dir: "out",
		cat: "parcelado",
		card: "neon",
		inst: "4/12",
		status: "pending"
	},
	{
		date: "2026-09-20",
		desc: "Cartão transporte",
		amount: 200,
		dir: "out",
		cat: "transporte",
		status: "pending"
	},
	{
		date: "2026-09-20",
		desc: "Sofá",
		amount: 288,
		dir: "out",
		cat: "parcelado",
		card: "ingrid",
		inst: "5/6",
		status: "pending"
	},
	{
		date: "2026-09-20",
		desc: "Ingrid",
		amount: 100,
		dir: "out",
		cat: "pessoal",
		status: "pending"
	},
	{
		date: "2026-09-20",
		desc: "Gás",
		amount: 65,
		dir: "out",
		cat: "moradia",
		status: "pending"
	},
	{
		date: "2026-09-20",
		desc: "Água / luz",
		amount: 200,
		dir: "out",
		cat: "moradia",
		status: "pending"
	},
	{
		date: "2026-09-20",
		desc: "Plano Cecília",
		amount: 240,
		dir: "out",
		cat: "saude",
		status: "pending",
		notes: "Hapvida"
	},
	{
		date: "2026-09-22",
		desc: "Compras",
		amount: 347,
		dir: "out",
		cat: "mercado",
		status: "pending"
	},
	{
		date: "2026-09-30",
		desc: "Celular TIM",
		amount: 140,
		dir: "out",
		cat: "celular",
		status: "pending"
	},
	{
		date: "2026-09-30",
		desc: "Plano NENA",
		amount: 288,
		dir: "out",
		cat: "saude",
		status: "pending",
		notes: "Hapvida"
	},
	{
		date: "2026-09-30",
		desc: "Internet Casa",
		amount: 100,
		dir: "out",
		cat: "moradia",
		status: "pending",
		notes: "Claro"
	},
	{
		date: "2026-09-30",
		desc: "Cartão Iasmim",
		amount: 540,
		dir: "out",
		cat: "cartao",
		card: "neon",
		status: "pending"
	},
	{
		date: "2026-09-30",
		desc: "Americanas",
		amount: 200,
		dir: "out",
		cat: "cartao",
		card: "americanas",
		status: "pending"
	},
	{
		date: "2026-09-05",
		desc: "Adiantamento Rafa e Gabi",
		amount: 2870,
		dir: "in",
		cat: "salario",
		status: "received"
	},
	{
		date: "2026-09-20",
		desc: "Salário Rafa e Gabi",
		amount: 2200,
		dir: "in",
		cat: "salario",
		status: "received"
	},
	{
		date: "2026-10-20",
		desc: "Guarda-roupa",
		amount: 60,
		dir: "out",
		cat: "parcelado",
		card: "neon",
		inst: "5/12",
		status: "pending"
	},
	{
		date: "2026-10-20",
		desc: "Cartão Neon Iasmim",
		amount: 458,
		dir: "out",
		cat: "cartao",
		card: "neon",
		status: "pending"
	},
	{
		date: "2026-10-10",
		desc: "Plano Cecília",
		amount: 250,
		dir: "out",
		cat: "saude",
		status: "pending"
	},
	{
		date: "2026-10-12",
		desc: "Água / Esgoto",
		amount: 178,
		dir: "out",
		cat: "moradia",
		status: "pending"
	},
	{
		date: "2026-10-20",
		desc: "Sofá",
		amount: 288,
		dir: "out",
		cat: "parcelado",
		card: "ingrid",
		inst: "6/6",
		status: "pending",
		notes: "Última parcela"
	},
	{
		date: "2026-10-30",
		desc: "Celular TIM",
		amount: 140,
		dir: "out",
		cat: "celular",
		status: "pending"
	},
	{
		date: "2026-10-30",
		desc: "Plano NENA",
		amount: 288,
		dir: "out",
		cat: "saude",
		status: "pending"
	},
	{
		date: "2026-10-30",
		desc: "Internet Casa",
		amount: 145,
		dir: "out",
		cat: "moradia",
		status: "pending"
	},
	{
		date: "2026-10-20",
		desc: "Credicard",
		amount: 200,
		dir: "out",
		cat: "cartao",
		card: "credicard",
		status: "pending"
	},
	{
		date: "2026-10-01",
		desc: "Parcela Empréstimo LECCA",
		amount: 560,
		dir: "out",
		cat: "emprestimo",
		inst: "1/36",
		status: "pending"
	},
	{
		date: "2026-10-05",
		desc: "Adiantamento Rafa e Gabi",
		amount: 2870,
		dir: "in",
		cat: "salario",
		status: "pending"
	},
	{
		date: "2026-10-20",
		desc: "Salário Rafa e Gabi",
		amount: 2210,
		dir: "in",
		cat: "salario",
		status: "pending"
	},
	{
		date: "2026-11-20",
		desc: "Guarda-roupa",
		amount: 60,
		dir: "out",
		cat: "parcelado",
		card: "neon",
		inst: "6/12",
		status: "pending"
	},
	{
		date: "2026-11-20",
		desc: "Neon Iasmim",
		amount: 458,
		dir: "out",
		cat: "cartao",
		card: "neon",
		status: "pending"
	},
	{
		date: "2026-11-10",
		desc: "Plano Cecília",
		amount: 250,
		dir: "out",
		cat: "saude",
		status: "pending"
	},
	{
		date: "2026-11-12",
		desc: "Água / Esgoto",
		amount: 200,
		dir: "out",
		cat: "moradia",
		status: "pending"
	},
	{
		date: "2026-11-30",
		desc: "Celular TIM",
		amount: 140,
		dir: "out",
		cat: "celular",
		status: "pending"
	},
	{
		date: "2026-11-30",
		desc: "Plano NENA",
		amount: 288,
		dir: "out",
		cat: "saude",
		status: "pending"
	},
	{
		date: "2026-11-30",
		desc: "Internet Casa",
		amount: 100,
		dir: "out",
		cat: "moradia",
		status: "pending"
	},
	{
		date: "2026-11-20",
		desc: "Credicard",
		amount: 200,
		dir: "out",
		cat: "cartao",
		card: "credicard",
		status: "pending"
	},
	{
		date: "2026-11-01",
		desc: "Parcela Empréstimo LECCA",
		amount: 560,
		dir: "out",
		cat: "emprestimo",
		inst: "2/36",
		status: "pending"
	},
	{
		date: "2026-11-05",
		desc: "Adiantamento Rafa e Gabi",
		amount: 2870,
		dir: "in",
		cat: "salario",
		status: "pending"
	},
	{
		date: "2026-11-20",
		desc: "Salário Rafa e Gabi",
		amount: 2200,
		dir: "in",
		cat: "salario",
		status: "pending"
	},
	{
		date: "2026-11-20",
		desc: "1ª parcela 13º Rafa",
		amount: 1400,
		dir: "in",
		cat: "extra",
		status: "pending"
	},
	{
		date: "2026-11-20",
		desc: "1ª parcela 13º Gabriela",
		amount: 434,
		dir: "in",
		cat: "extra",
		status: "pending"
	},
	{
		date: "2026-12-20",
		desc: "Guarda-roupa",
		amount: 60,
		dir: "out",
		cat: "parcelado",
		card: "neon",
		inst: "7/12",
		status: "pending"
	},
	{
		date: "2026-12-20",
		desc: "Neon Iasmim",
		amount: 108,
		dir: "out",
		cat: "cartao",
		card: "neon",
		status: "pending"
	},
	{
		date: "2026-12-10",
		desc: "Plano Cecília",
		amount: 250,
		dir: "out",
		cat: "saude",
		status: "pending"
	},
	{
		date: "2026-12-12",
		desc: "Água / Esgoto",
		amount: 178,
		dir: "out",
		cat: "moradia",
		status: "pending"
	},
	{
		date: "2026-12-30",
		desc: "Celular TIM",
		amount: 140,
		dir: "out",
		cat: "celular",
		status: "pending"
	},
	{
		date: "2026-12-30",
		desc: "Plano NENA",
		amount: 288,
		dir: "out",
		cat: "saude",
		status: "pending"
	},
	{
		date: "2026-12-30",
		desc: "Internet Casa",
		amount: 100,
		dir: "out",
		cat: "moradia",
		status: "pending"
	},
	{
		date: "2026-12-20",
		desc: "Casa Bahia",
		amount: 224,
		dir: "out",
		cat: "parcelado",
		inst: "5/5",
		status: "pending"
	},
	{
		date: "2026-12-20",
		desc: "Credicard",
		amount: 200,
		dir: "out",
		cat: "cartao",
		card: "credicard",
		status: "pending"
	},
	{
		date: "2026-12-20",
		desc: "Curso Eletrotécnico",
		amount: 300,
		dir: "out",
		cat: "parcelado",
		inst: "3/5",
		status: "pending"
	},
	{
		date: "2026-12-01",
		desc: "Parcela Empréstimo LECCA",
		amount: 560,
		dir: "out",
		cat: "emprestimo",
		inst: "3/36",
		status: "pending"
	},
	{
		date: "2026-12-05",
		desc: "Adiantamento Rafa e Gabi",
		amount: 2880,
		dir: "in",
		cat: "salario",
		status: "pending"
	},
	{
		date: "2026-12-20",
		desc: "Salário Rafa e Gabi",
		amount: 2200,
		dir: "in",
		cat: "salario",
		status: "pending"
	},
	{
		date: "2026-12-20",
		desc: "2ª parcela 13º Rafa",
		amount: 1400,
		dir: "in",
		cat: "extra",
		status: "pending"
	},
	{
		date: "2026-12-20",
		desc: "2ª parcela 13º Gabriela",
		amount: 434,
		dir: "in",
		cat: "extra",
		status: "pending"
	}
];
var INVESTMENTS = [
	{
		month: "2026-06-01",
		contribution: 0,
		yieldAmount: 0,
		balance: 0
	},
	{
		month: "2026-07-01",
		contribution: 0,
		yieldAmount: 0,
		balance: 0
	},
	{
		month: "2026-08-01",
		contribution: 400,
		yieldAmount: 4.6,
		balance: 500
	},
	{
		month: "2026-09-01",
		contribution: 2e3,
		yieldAmount: 28.75,
		balance: 2528.75
	}
];
var COST_ACTIONS = [
	{
		name: "Celular TIM",
		current: 140,
		target: 70,
		status: "pending",
		note: "Migrar para operadora digital (Claro/Vivo/C6)"
	},
	{
		name: "Plano NENA",
		current: 288,
		target: 180,
		status: "ok",
		note: "Inegociável no momento — manter"
	},
	{
		name: "Plano Cecília",
		current: 240,
		target: 160,
		status: "ok",
		note: "Verificar plano familiar/combo com NENA"
	},
	{
		name: "Internet Casa",
		current: 135,
		target: 100,
		status: "pending",
		note: "Negociar fidelidade ou trocar provedor"
	},
	{
		name: "Energia",
		current: 200,
		target: 150,
		status: "pending",
		note: "Hábitos de consumo e lâmpadas LED"
	},
	{
		name: "Água / Esgoto",
		current: 200,
		target: 200,
		status: "ok",
		note: "Custo fixo externo — sem ação imediata"
	},
	{
		name: "Neon Fasomim",
		current: 86,
		target: 0,
		status: "paying_off",
		note: "Parcelado — última parcela em julho"
	}
];
/** Price table from the LECCA proposal (36 months). */
var LOAN_SCHEDULE = [
	{
		installment: 1,
		due: "2026-10-01",
		open: 13600,
		interest: 337.27,
		amort: 222.73,
		payment: 560,
		close: 13377.27
	},
	{
		installment: 2,
		due: "2026-11-01",
		open: 13377.27,
		interest: 331.75,
		amort: 228.25,
		payment: 560,
		close: 13149.02
	},
	{
		installment: 3,
		due: "2026-12-01",
		open: 13149.02,
		interest: 326.09,
		amort: 233.91,
		payment: 560,
		close: 12915.1
	},
	{
		installment: 4,
		due: "2027-01-01",
		open: 12915.1,
		interest: 320.28,
		amort: 239.72,
		payment: 560,
		close: 12675.38
	},
	{
		installment: 5,
		due: "2027-02-01",
		open: 12675.38,
		interest: 314.34,
		amort: 245.66,
		payment: 560,
		close: 12429.72
	},
	{
		installment: 6,
		due: "2027-03-01",
		open: 12429.72,
		interest: 308.25,
		amort: 251.75,
		payment: 560,
		close: 12177.97
	},
	{
		installment: 7,
		due: "2027-04-01",
		open: 12177.97,
		interest: 302,
		amort: 258,
		payment: 560,
		close: 11919.98
	},
	{
		installment: 8,
		due: "2027-05-01",
		open: 11919.98,
		interest: 295.61,
		amort: 264.39,
		payment: 560,
		close: 11655.58
	},
	{
		installment: 9,
		due: "2027-06-01",
		open: 11655.58,
		interest: 289.05,
		amort: 270.95,
		payment: 560,
		close: 11384.63
	},
	{
		installment: 10,
		due: "2027-07-01",
		open: 11384.63,
		interest: 282.33,
		amort: 277.67,
		payment: 560,
		close: 11106.96
	},
	{
		installment: 11,
		due: "2027-08-01",
		open: 11106.96,
		interest: 275.44,
		amort: 284.56,
		payment: 560,
		close: 10822.4
	},
	{
		installment: 12,
		due: "2027-09-01",
		open: 10822.4,
		interest: 268.39,
		amort: 291.61,
		payment: 560,
		close: 10530.79
	},
	{
		installment: 13,
		due: "2027-10-01",
		open: 10530.79,
		interest: 261.16,
		amort: 298.84,
		payment: 560,
		close: 10231.95
	},
	{
		installment: 14,
		due: "2027-11-01",
		open: 10231.95,
		interest: 253.74,
		amort: 306.26,
		payment: 560,
		close: 9925.69
	},
	{
		installment: 15,
		due: "2027-12-01",
		open: 9925.69,
		interest: 246.15,
		amort: 313.85,
		payment: 560,
		close: 9611.84
	},
	{
		installment: 16,
		due: "2028-01-01",
		open: 9611.84,
		interest: 238.37,
		amort: 321.63,
		payment: 560,
		close: 9290.21
	},
	{
		installment: 17,
		due: "2028-02-01",
		open: 9290.21,
		interest: 230.39,
		amort: 329.61,
		payment: 560,
		close: 8960.6
	},
	{
		installment: 18,
		due: "2028-03-01",
		open: 8960.6,
		interest: 222.22,
		amort: 337.78,
		payment: 560,
		close: 8622.81
	},
	{
		installment: 19,
		due: "2028-04-01",
		open: 8622.81,
		interest: 213.84,
		amort: 346.16,
		payment: 560,
		close: 8276.65
	},
	{
		installment: 20,
		due: "2028-05-01",
		open: 8276.65,
		interest: 205.25,
		amort: 354.75,
		payment: 560,
		close: 7921.91
	},
	{
		installment: 21,
		due: "2028-06-01",
		open: 7921.91,
		interest: 196.46,
		amort: 363.54,
		payment: 560,
		close: 7558.36
	},
	{
		installment: 22,
		due: "2028-07-01",
		open: 7558.36,
		interest: 187.44,
		amort: 372.56,
		payment: 560,
		close: 7185.8
	},
	{
		installment: 23,
		due: "2028-08-01",
		open: 7185.8,
		interest: 178.2,
		amort: 381.8,
		payment: 560,
		close: 6804.01
	},
	{
		installment: 24,
		due: "2028-09-01",
		open: 6804.01,
		interest: 168.73,
		amort: 391.27,
		payment: 560,
		close: 6412.74
	},
	{
		installment: 25,
		due: "2028-10-01",
		open: 6412.74,
		interest: 159.03,
		amort: 400.97,
		payment: 560,
		close: 6011.77
	},
	{
		installment: 26,
		due: "2028-11-01",
		open: 6011.77,
		interest: 149.09,
		amort: 410.91,
		payment: 560,
		close: 5600.86
	},
	{
		installment: 27,
		due: "2028-12-01",
		open: 5600.86,
		interest: 138.9,
		amort: 421.1,
		payment: 560,
		close: 5179.76
	},
	{
		installment: 28,
		due: "2029-01-01",
		open: 5179.76,
		interest: 128.45,
		amort: 431.55,
		payment: 560,
		close: 4748.21
	},
	{
		installment: 29,
		due: "2029-02-01",
		open: 4748.21,
		interest: 117.75,
		amort: 442.25,
		payment: 560,
		close: 4305.96
	},
	{
		installment: 30,
		due: "2029-03-01",
		open: 4305.96,
		interest: 106.78,
		amort: 453.22,
		payment: 560,
		close: 3852.75
	},
	{
		installment: 31,
		due: "2029-04-01",
		open: 3852.75,
		interest: 95.55,
		amort: 464.45,
		payment: 560,
		close: 3388.29
	},
	{
		installment: 32,
		due: "2029-05-01",
		open: 3388.29,
		interest: 84.03,
		amort: 475.97,
		payment: 560,
		close: 2912.32
	},
	{
		installment: 33,
		due: "2029-06-01",
		open: 2912.32,
		interest: 72.22,
		amort: 487.78,
		payment: 560,
		close: 2424.54
	},
	{
		installment: 34,
		due: "2029-07-01",
		open: 2424.54,
		interest: 60.13,
		amort: 499.87,
		payment: 560,
		close: 1924.67
	},
	{
		installment: 35,
		due: "2029-08-01",
		open: 1924.67,
		interest: 47.73,
		amort: 512.27,
		payment: 560,
		close: 1412.4
	},
	{
		installment: 36,
		due: "2029-09-01",
		open: 1412.4,
		interest: 35.03,
		amort: 1412.4,
		payment: 1447.42,
		close: 0
	}
];
async function ensureSeeded(userId) {
	const sql = await getSql();
	if ((await sql`
    select user_id from profiles where user_id = ${userId}
  `).length) return;
	const catIds = /* @__PURE__ */ new Map();
	for (const c of CATEGORIES) {
		const id = uid("cat");
		catIds.set(c.key, id);
		await sql`
      insert into categories (id, user_id, name, kind, tone, icon)
      values (${id}, ${userId}, ${c.name}, ${c.kind}, ${c.tone}, ${c.icon})
    `;
	}
	const cardIds = /* @__PURE__ */ new Map();
	for (const c of CARDS) {
		const id = uid("card");
		cardIds.set(c.key, id);
		await sql`
      insert into cards (id, user_id, name, holder, brand, credit_limit, closing_day, due_day)
      values (${id}, ${userId}, ${c.name}, ${c.holder}, ${c.brand}, ${c.limit}, ${c.closing}, ${c.due})
    `;
	}
	for (const t of TRANSACTIONS) await sql`
      insert into transactions (
        id, user_id, occurred_on, description, amount, direction,
        category_id, card_id, installment_label, status, notes
      ) values (
        ${uid("tx")}, ${userId}, ${t.date}::date, ${t.desc}, ${t.amount}, ${t.dir},
        ${catIds.get(t.cat) ?? null}, ${t.card ? cardIds.get(t.card) ?? null : null},
        ${t.inst ?? null}, ${t.status}, ${t.notes ?? null}
      )
    `;
	for (const i of INVESTMENTS) await sql`
      insert into investments (id, user_id, month, contribution, yield_amount, balance)
      values (${uid("inv")}, ${userId}, ${i.month}::date, ${i.contribution}, ${i.yieldAmount}, ${i.balance})
    `;
	for (const p of LOAN_SCHEDULE) await sql`
      insert into loan_payments (
        id, user_id, installment, due_on, opening_balance, interest_amount,
        amortization, payment, closing_balance, paid
      ) values (
        ${uid("loan")}, ${userId}, ${p.installment}, ${p.due}::date, ${p.open}, ${p.interest},
        ${p.amort}, ${p.payment}, ${p.close}, false
      )
    `;
	const lastInv = INVESTMENTS[INVESTMENTS.length - 1];
	await sql`
    insert into goals (id, user_id, name, target_amount, current_amount, deadline, kind)
    values (
      ${uid("goal")}, ${userId}, ${"Reserva de emergência"}, ${1e4},
      ${lastInv.balance}, ${"2026-11-30"}::date, ${"emergency"}
    )
  `;
	for (const a of COST_ACTIONS) await sql`
      insert into cost_actions (id, user_id, expense_name, current_amount, target_amount, status, action_note)
      values (${uid("cost")}, ${userId}, ${a.name}, ${a.current}, ${a.target}, ${a.status}, ${a.note})
    `;
	await sql`
    insert into settings (user_id) values (${userId})
  `;
	await sql`
    insert into profiles (user_id, display_name, seeded_at)
    values (${userId}, ${"Casa"}, now())
  `;
}
function mapTx(row) {
	return {
		id: row.id,
		occurredOn: row.occurred_on,
		description: row.description,
		amount: num(row.amount),
		direction: row.direction,
		categoryId: row.category_id,
		cardId: row.card_id,
		installment: row.installment_label,
		status: row.status,
		notes: row.notes,
		categoryName: row.cat_name,
		categoryTone: row.cat_tone,
		cardName: row.card_name
	};
}
var getBootstrap_createServerFn_handler = createServerRpc({
	id: "367d7efc4fb32297ca7dd8cc1e9561e736e0063b040d8f91e597d806e090e5bd",
	name: "getBootstrap",
	filename: "src/lib/server/finance.ts"
}, (opts) => getBootstrap.__executeServer(opts));
var getBootstrap = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getBootstrap_createServerFn_handler, async ({ context }) => {
	await ensureSeeded(context.userId);
	const sql = await getSql();
	return {
		categories: await sql`
      select id, name, kind, tone, icon from categories where user_id = ${context.userId} order by kind, name
    `,
		cards: (await sql`
      select id, name, holder, brand, credit_limit, closing_day, due_day
      from cards where user_id = ${context.userId} order by name
    `).map((c) => ({
			id: c.id,
			name: c.name,
			holder: c.holder,
			brand: c.brand,
			creditLimit: num(c.credit_limit),
			closingDay: c.closing_day,
			dueDay: c.due_day
		}))
	};
});
var getOverview_createServerFn_handler = createServerRpc({
	id: "ad7416cc6ce4d5ff48b603e0a035945d1fe0450cdd4646c1cf7f3a3cc13b88e4",
	name: "getOverview",
	filename: "src/lib/server/finance.ts"
}, (opts) => getOverview.__executeServer(opts));
var getOverview = createServerFn({ method: "GET" }).validator((input) => input ?? {}).middleware([authMiddleware]).handler(getOverview_createServerFn_handler, async ({ context, data }) => {
	await ensureSeeded(context.userId);
	const sql = await getSql();
	const month = data.month && /^\d{4}-\d{2}$/.test(data.month) ? data.month : currentMonthKey();
	const start = `${month}-01`;
	const next = `${shiftMonth(month, 1)}-01`;
	const yearStart = `${month.slice(0, 4)}-01-01`;
	const monthTx = await sql`
      select t.id, t.occurred_on::text as occurred_on, t.description, t.amount, t.direction,
             t.category_id, t.card_id, t.installment_label, t.status, t.notes,
             c.name as cat_name, c.tone as cat_tone, k.name as card_name
      from transactions t
      left join categories c on c.id = t.category_id
      left join cards k on k.id = t.card_id
      where t.user_id = ${context.userId}
        and t.occurred_on >= ${start}::date
        and t.occurred_on < ${next}::date
      order by t.occurred_on, t.description
    `;
	const history = await sql`
      select to_char(date_trunc('month', occurred_on), 'YYYY-MM') as month,
             coalesce(sum(case when direction = 'in' then amount else 0 end), 0) as income,
             coalesce(sum(case when direction = 'out' then amount else 0 end), 0) as expense
      from transactions
      where user_id = ${context.userId}
        and occurred_on >= ${yearStart}::date
      group by 1
      order by 1
    `;
	const investments = await sql`
      select id, month::text as month, contribution, yield_amount, balance
      from investments where user_id = ${context.userId} order by month
    `;
	const loan = await sql`
      select id, installment, due_on::text as due_on, opening_balance, interest_amount,
             amortization, payment, closing_balance, paid
      from loan_payments where user_id = ${context.userId} order by installment
    `;
	const goals = await sql`
      select id, name, target_amount, current_amount, deadline::text as deadline, kind
      from goals where user_id = ${context.userId} order by kind
    `;
	const costs = await sql`
      select id, expense_name, current_amount, target_amount, status, action_note
      from cost_actions where user_id = ${context.userId} order by current_amount desc
    `;
	const settingsRows = await sql`
      select monthly_yield_rate, invest_pct, emergency_target, loan_principal, loan_installment, loan_cet
      from settings where user_id = ${context.userId}
    `;
	const income = monthTx.filter((t) => t.direction === "in").reduce((s, t) => s + num(t.amount), 0);
	const expense = monthTx.filter((t) => t.direction === "out").reduce((s, t) => s + num(t.amount), 0);
	const paidOut = monthTx.filter((t) => t.direction === "out" && t.status === "paid").reduce((s, t) => s + num(t.amount), 0);
	const pendingOut = expense - paidOut;
	const received = monthTx.filter((t) => t.direction === "in" && t.status === "received").reduce((s, t) => s + num(t.amount), 0);
	const byCategory = /* @__PURE__ */ new Map();
	for (const t of monthTx) {
		if (t.direction !== "out") continue;
		const key = t.cat_name ?? "Outros";
		const prev = byCategory.get(key) ?? {
			name: key,
			tone: t.cat_tone ?? "muted",
			total: 0
		};
		prev.total += num(t.amount);
		byCategory.set(key, prev);
	}
	const lastInv = investments.at(-1);
	const invBalance = lastInv ? num(lastInv.balance) : 0;
	const nextLoan = loan.find((p) => !p.paid);
	const emergency = goals.find((g) => g.kind === "emergency");
	const savings = costs.reduce((s, c) => s + Math.max(0, num(c.current_amount) - num(c.target_amount)), 0);
	const upcoming = monthTx.filter((t) => t.direction === "out" && t.status !== "paid").slice().sort((a, b) => a.occurred_on.localeCompare(b.occurred_on)).slice(0, 6).map(mapTx);
	const insights = buildInsights({
		month,
		income,
		expense,
		invBalance,
		emergencyTarget: emergency ? num(emergency.target_amount) : 1e4,
		nextLoan: nextLoan ? {
			due: nextLoan.due_on,
			payment: num(nextLoan.payment),
			installment: nextLoan.installment
		} : null,
		costs: costs.map((c) => ({
			name: c.expense_name,
			current: num(c.current_amount),
			target: num(c.target_amount),
			status: c.status
		})),
		byCategory: [...byCategory.values()],
		monthTx: monthTx.map(mapTx)
	});
	return {
		month,
		income,
		expense,
		balance: income - expense,
		ratio: income > 0 ? (income - expense) / income : 0,
		paidOut,
		pendingOut,
		received,
		leftover: income - expense,
		byCategory: [...byCategory.values()].sort((a, b) => b.total - a.total),
		history: history.map((h) => ({
			month: h.month,
			income: num(h.income),
			expense: num(h.expense),
			balance: num(h.income) - num(h.expense)
		})),
		investmentBalance: invBalance,
		nextLoan: nextLoan ? {
			due: nextLoan.due_on,
			payment: num(nextLoan.payment),
			installment: nextLoan.installment,
			remaining: num(nextLoan.opening_balance)
		} : null,
		emergency: emergency ? {
			name: emergency.name,
			current: invBalance,
			target: num(emergency.target_amount),
			deadline: emergency.deadline
		} : null,
		potentialSaving: savings,
		upcoming,
		insights,
		recent: monthTx.slice(-8).reverse().map(mapTx),
		settings: settingsRows[0] ? {
			yieldRate: num(settingsRows[0].monthly_yield_rate),
			investPct: num(settingsRows[0].invest_pct),
			emergencyTarget: num(settingsRows[0].emergency_target),
			loanPrincipal: num(settingsRows[0].loan_principal),
			loanInstallment: num(settingsRows[0].loan_installment),
			loanCet: num(settingsRows[0].loan_cet)
		} : null
	};
});
function buildInsights(input) {
	const items = [];
	const leftover = input.income - input.expense;
	const suggested = leftover * .5;
	if (input.income > 0) items.push({
		id: "audit",
		tone: leftover > 0 ? "ok" : "risk",
		title: "Auditoria do mês",
		body: leftover >= 0 ? `Sobram ${formatInsightMoney(leftover)} neste mês (${Math.round(leftover / input.income * 100)}% da receita). Aporte sugerido: ${formatInsightMoney(suggested)}.` : `O mês fecha negativo em ${formatInsightMoney(Math.abs(leftover))}. Priorize cortar gerais e cartão antes de investir.`
	});
	const top = input.byCategory[0];
	if (top) items.push({
		id: "leak",
		tone: top.total > input.income * .2 ? "warn" : "info",
		title: "Detector de vazamentos",
		body: `${top.name} é a maior saída (${formatInsightMoney(top.total)}). Planos de saúde somados passam de R$ 500/mês — vale um combo familiar.`
	});
	const pendingCuts = input.costs.filter((c) => c.status === "pending" && c.current > c.target);
	const save = pendingCuts.reduce((s, c) => s + (c.current - c.target), 0);
	if (save > 0) items.push({
		id: "cuts",
		tone: "warn",
		title: "Redução de custos",
		body: `${pendingCuts.length} contas ainda dá para negociar. Economia potencial: ${formatInsightMoney(save)}/mês — ${formatInsightMoney(save * 12)} no ano.`
	});
	const reservePct = input.emergencyTarget > 0 ? input.invBalance / input.emergencyTarget : 0;
	items.push({
		id: "reserve",
		tone: reservePct >= 1 ? "ok" : reservePct >= .4 ? "info" : "warn",
		title: "Plano de riqueza",
		body: reservePct >= 1 ? `Reserva completa. Mantenha o aporte e deixe o CDB trabalhar.` : `Reserva em ${Math.round(reservePct * 100)}% da meta de ${formatInsightMoney(input.emergencyTarget)}. Faltam ${formatInsightMoney(Math.max(0, input.emergencyTarget - input.invBalance))}.`
	});
	if (input.nextLoan) items.push({
		id: "loan",
		tone: "info",
		title: "Otimizador de caixa",
		body: `Parcela ${input.nextLoan.installment}/36 do LECCA (${formatInsightMoney(input.nextLoan.payment)}) vence em ${formatDate(input.nextLoan.due)}. Pague depois do adiantamento do dia 5 para não furar o caixa.`
	});
	const lastParcel = input.monthTx.find((t) => t.installment?.includes("/6") && t.description.toLowerCase().includes("sof"));
	if (lastParcel) items.push({
		id: "sofa",
		tone: "ok",
		title: "Parcelamento acabando",
		body: `Sofá ${lastParcel.installment} — depois disso o caixa ganha ${formatInsightMoney(lastParcel.amount)} todo mês.`
	});
	return items;
}
function formatInsightMoney(n) {
	return n.toLocaleString("pt-BR", {
		style: "currency",
		currency: "BRL"
	});
}
function formatDate(iso) {
	const [y, m, d] = iso.slice(0, 10).split("-");
	return `${d}/${m}/${y}`;
}
var listTransactions_createServerFn_handler = createServerRpc({
	id: "e03546459a130f53aa8fe4aef82ec86cf742ced71ca1395f82de3ec35150c401",
	name: "listTransactions",
	filename: "src/lib/server/finance.ts"
}, (opts) => listTransactions.__executeServer(opts));
var listTransactions = createServerFn({ method: "GET" }).validator((input) => input ?? {}).middleware([authMiddleware]).handler(listTransactions_createServerFn_handler, async ({ context, data }) => {
	await ensureSeeded(context.userId);
	const sql = await getSql();
	const month = data.month && /^\d{4}-\d{2}$/.test(data.month) ? data.month : currentMonthKey();
	const start = `${month}-01`;
	const next = `${shiftMonth(month, 1)}-01`;
	const list = (await sql`
      select t.id, t.occurred_on::text as occurred_on, t.description, t.amount, t.direction,
             t.category_id, t.card_id, t.installment_label, t.status, t.notes,
             c.name as cat_name, c.tone as cat_tone, k.name as card_name
      from transactions t
      left join categories c on c.id = t.category_id
      left join cards k on k.id = t.card_id
      where t.user_id = ${context.userId}
        and t.occurred_on >= ${start}::date
        and t.occurred_on < ${next}::date
      order by t.occurred_on desc, t.created_at desc
    `).map(mapTx).filter((t) => !data.direction || t.direction === data.direction);
	const income = list.filter((t) => t.direction === "in").reduce((s, t) => s + t.amount, 0);
	const expense = list.filter((t) => t.direction === "out").reduce((s, t) => s + t.amount, 0);
	return {
		month,
		items: list,
		income,
		expense,
		balance: income - expense
	};
});
var addTransaction_createServerFn_handler = createServerRpc({
	id: "dc397eda079a4b30bc0c5d76f58da53864aa941988bd8e0b3a49447d78b23517",
	name: "addTransaction",
	filename: "src/lib/server/finance.ts"
}, (opts) => addTransaction.__executeServer(opts));
var addTransaction = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(addTransaction_createServerFn_handler, async ({ context, data }) => {
	if (!data.description.trim() || !Number.isFinite(data.amount) || data.amount <= 0) throw new Error("Informe descrição e um valor válido.");
	const sql = await getSql();
	const id = uid("tx");
	await sql`
      insert into transactions (
        id, user_id, occurred_on, description, amount, direction,
        category_id, card_id, installment_label, status, notes
      ) values (
        ${id}, ${context.userId}, ${data.occurredOn}::date, ${data.description.trim()}, ${data.amount},
        ${data.direction}, ${data.categoryId ?? null}, ${data.cardId ?? null},
        ${data.installment ?? null}, ${data.status ?? (data.direction === "in" ? "received" : "pending")},
        ${data.notes ?? null}
      )
    `;
	return { id };
});
var toggleTransaction_createServerFn_handler = createServerRpc({
	id: "f430dc67295716eb3911a28efe6f5e67d9c7c1cdf6a94742d788a74d5cad00c1",
	name: "toggleTransaction",
	filename: "src/lib/server/finance.ts"
}, (opts) => toggleTransaction.__executeServer(opts));
var toggleTransaction = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(toggleTransaction_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const row = (await sql`
      select id, direction, status from transactions where id = ${data.id} and user_id = ${context.userId}
    `)[0];
	if (!row) throw new Error("Lançamento não encontrado");
	const next = row.direction === "in" ? row.status === "received" ? "pending" : "received" : row.status === "paid" ? "pending" : "paid";
	await sql`
      update transactions set status = ${next} where id = ${data.id} and user_id = ${context.userId}
    `;
	return { status: next };
});
var deleteTransaction_createServerFn_handler = createServerRpc({
	id: "88ba13589545508c1e6bc130638a70dc42613a84254861d6b86e22e4eb7673c3",
	name: "deleteTransaction",
	filename: "src/lib/server/finance.ts"
}, (opts) => deleteTransaction.__executeServer(opts));
var deleteTransaction = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(deleteTransaction_createServerFn_handler, async ({ context, data }) => {
	await (await getSql())`delete from transactions where id = ${data.id} and user_id = ${context.userId}`;
	return { ok: true };
});
var upsertCard_createServerFn_handler = createServerRpc({
	id: "676b60af1b0376d2327d236ce97cbcef75bbfdb30dd6f17166028c113fbc77d6",
	name: "upsertCard",
	filename: "src/lib/server/finance.ts"
}, (opts) => upsertCard.__executeServer(opts));
var upsertCard = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(upsertCard_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	if (data.id) {
		await sql`
        update cards
        set name = ${data.name}, holder = ${data.holder ?? null}, brand = ${data.brand ?? null},
            credit_limit = ${data.creditLimit}, closing_day = ${data.closingDay}, due_day = ${data.dueDay}
        where id = ${data.id} and user_id = ${context.userId}
      `;
		return { id: data.id };
	}
	const id = uid("card");
	await sql`
      insert into cards (id, user_id, name, holder, brand, credit_limit, closing_day, due_day)
      values (${id}, ${context.userId}, ${data.name}, ${data.holder ?? null}, ${data.brand ?? null},
              ${data.creditLimit}, ${data.closingDay}, ${data.dueDay})
    `;
	return { id };
});
var getCards_createServerFn_handler = createServerRpc({
	id: "6c3934b78d960a3a4aeecd5ec760fef4e545b1795f21f3c575084da6ec4a5eab",
	name: "getCards",
	filename: "src/lib/server/finance.ts"
}, (opts) => getCards.__executeServer(opts));
var getCards = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getCards_createServerFn_handler, async ({ context }) => {
	await ensureSeeded(context.userId);
	const sql = await getSql();
	const month = currentMonthKey();
	const start = `${month}-01`;
	const next = `${shiftMonth(month, 1)}-01`;
	const cards = await sql`
      select id, name, holder, brand, credit_limit, closing_day, due_day
      from cards where user_id = ${context.userId} order by name
    `;
	const spend = await sql`
      select card_id, coalesce(sum(amount), 0) as total
      from transactions
      where user_id = ${context.userId}
        and direction = 'out'
        and card_id is not null
        and occurred_on >= ${start}::date
        and occurred_on < ${next}::date
      group by card_id
    `;
	const spendMap = new Map(spend.map((s) => [s.card_id, num(s.total)]));
	const parcels = await sql`
      select t.id, t.occurred_on::text as occurred_on, t.description, t.amount, t.direction,
             t.category_id, t.card_id, t.installment_label, t.status, t.notes,
             c.name as cat_name, c.tone as cat_tone, k.name as card_name
      from transactions t
      left join categories c on c.id = t.category_id
      left join cards k on k.id = t.card_id
      where t.user_id = ${context.userId}
        and t.installment_label is not null
        and t.occurred_on >= ${start}::date
      order by t.occurred_on
    `;
	return {
		month,
		cards: cards.map((c) => {
			const used = spendMap.get(c.id) ?? 0;
			const limit = num(c.credit_limit);
			return {
				id: c.id,
				name: c.name,
				holder: c.holder,
				brand: c.brand,
				creditLimit: limit,
				closingDay: c.closing_day,
				dueDay: c.due_day,
				used,
				available: Math.max(0, limit - used)
			};
		}),
		parcels: parcels.map(mapTx)
	};
});
var getInvestments_createServerFn_handler = createServerRpc({
	id: "0e53d672f065621b11f48ccb7fae180a8bcebafedb4f8eff6dd1ace45ac7831b",
	name: "getInvestments",
	filename: "src/lib/server/finance.ts"
}, (opts) => getInvestments.__executeServer(opts));
var getInvestments = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getInvestments_createServerFn_handler, async ({ context }) => {
	await ensureSeeded(context.userId);
	const sql = await getSql();
	const rows = await sql`
      select id, month::text as month, contribution, yield_amount, balance
      from investments where user_id = ${context.userId} order by month
    `;
	const settings = await sql`
      select monthly_yield_rate, invest_pct, emergency_target, loan_principal, loan_installment, loan_cet
      from settings where user_id = ${context.userId}
    `;
	const rate = settings[0] ? num(settings[0].monthly_yield_rate) : .0115;
	const last = rows.at(-1);
	const startBalance = last ? num(last.balance) : 0;
	const projection = projectInvestment(startBalance, 2e3, rate, 24);
	return {
		history: rows.map((r) => ({
			id: r.id,
			month: monthKey(r.month),
			contribution: num(r.contribution),
			yieldAmount: num(r.yield_amount),
			balance: num(r.balance)
		})),
		rate,
		emergencyTarget: settings[0] ? num(settings[0].emergency_target) : 1e4,
		current: startBalance,
		projection
	};
});
function projectInvestment(start, aporte, rate, months) {
	const out = [];
	let bal = start;
	for (let i = 1; i <= months; i++) {
		const yieldAmount = bal * rate;
		bal = bal + aporte + yieldAmount;
		out.push({
			monthOffset: i,
			contribution: aporte,
			yieldAmount,
			balance: bal
		});
	}
	return out;
}
var addContribution_createServerFn_handler = createServerRpc({
	id: "1ad47f973ee48d32a7817318eec5733cbe30bb91c03bda29c76a964b6018e5d1",
	name: "addContribution",
	filename: "src/lib/server/finance.ts"
}, (opts) => addContribution.__executeServer(opts));
var addContribution = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(addContribution_createServerFn_handler, async ({ context, data }) => {
	if (!Number.isFinite(data.amount) || data.amount <= 0) throw new Error("Informe um aporte válido.");
	const sql = await getSql();
	const month = (data.month && /^\d{4}-\d{2}$/.test(data.month) ? data.month : currentMonthKey()) + "-01";
	const settings = await sql`
      select monthly_yield_rate from settings where user_id = ${context.userId}
    `;
	const rate = settings[0] ? num(settings[0].monthly_yield_rate) : .0115;
	const prev = await sql`
      select id, month::text as month, contribution, yield_amount, balance
      from investments where user_id = ${context.userId} order by month desc limit 1
    `;
	const lastBal = prev[0] ? num(prev[0].balance) : 0;
	const yieldAmount = lastBal * rate;
	const balance = lastBal + data.amount + yieldAmount;
	const existing = await sql`
      select id from investments where user_id = ${context.userId} and month = ${month}::date
    `;
	if (existing[0]) await sql`
        update investments
        set contribution = ${data.amount}, yield_amount = ${yieldAmount}, balance = ${balance}
        where id = ${existing[0].id} and user_id = ${context.userId}
      `;
	else await sql`
        insert into investments (id, user_id, month, contribution, yield_amount, balance)
        values (${uid("inv")}, ${context.userId}, ${month}::date, ${data.amount}, ${yieldAmount}, ${balance})
      `;
	await sql`
      update goals set current_amount = ${balance}
      where user_id = ${context.userId} and kind = 'emergency'
    `;
	return { balance };
});
var getLoan_createServerFn_handler = createServerRpc({
	id: "d1f1016ba0ea814997ae02b5ddc79a2c3cbbf20476a1d6ecdb8251dcc1d98af0",
	name: "getLoan",
	filename: "src/lib/server/finance.ts"
}, (opts) => getLoan.__executeServer(opts));
var getLoan = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getLoan_createServerFn_handler, async ({ context }) => {
	await ensureSeeded(context.userId);
	const sql = await getSql();
	const rows = await sql`
      select id, installment, due_on::text as due_on, opening_balance, interest_amount,
             amortization, payment, closing_balance, paid
      from loan_payments where user_id = ${context.userId} order by installment
    `;
	const settings = await sql`
      select loan_principal, loan_installment, loan_cet, monthly_yield_rate
      from settings where user_id = ${context.userId}
    `;
	const inv = await sql`
      select id, month::text as month, contribution, yield_amount, balance
      from investments where user_id = ${context.userId} order by month desc limit 1
    `;
	const payments = rows.map((r) => ({
		id: r.id,
		installment: r.installment,
		dueOn: r.due_on,
		opening: num(r.opening_balance),
		interest: num(r.interest_amount),
		amort: num(r.amortization),
		payment: num(r.payment),
		closing: num(r.closing_balance),
		paid: Boolean(r.paid)
	}));
	const totalInterest = payments.reduce((s, p) => s + p.interest, 0);
	const totalPaid = payments.reduce((s, p) => s + p.payment, 0);
	const remaining = payments.filter((p) => !p.paid);
	const next = remaining[0] ?? null;
	const rate = settings[0] ? num(settings[0].monthly_yield_rate) : .0116;
	const avgInterest = totalInterest / Math.max(payments.length, 1);
	const cruzamento = buildCruzamento(inv[0] ? num(inv[0].balance) : 2528.75, 1500, rate, avgInterest, 36);
	return {
		principal: settings[0] ? num(settings[0].loan_principal) : 13600,
		installment: settings[0] ? num(settings[0].loan_installment) : 560,
		cet: settings[0] ? num(settings[0].loan_cet) : .0243,
		totalInterest,
		totalPaid,
		remainingCount: remaining.length,
		remainingBalance: next ? next.opening : 0,
		next,
		payments,
		cruzamento
	};
});
function buildCruzamento(startInvest, aporte, yieldRate, avgLoanInterest, months) {
	const rows = [];
	let bal = startInvest;
	let cross = null;
	for (let i = 1; i <= months; i++) {
		const yieldAmount = bal * yieldRate;
		bal = bal + aporte + yieldAmount;
		const diff = yieldAmount - avgLoanInterest;
		if (cross === null && diff > 0) cross = i;
		rows.push({
			month: i,
			loanInterest: avgLoanInterest,
			yieldAmount,
			diff,
			balance: bal
		});
	}
	return {
		avgLoanInterest,
		crossMonth: cross,
		totalYield: rows.reduce((s, r) => s + r.yieldAmount, 0),
		totalLoanInterest: avgLoanInterest * months,
		finalBalance: rows.at(-1)?.balance ?? startInvest,
		rows
	};
}
var toggleLoanPaid_createServerFn_handler = createServerRpc({
	id: "e5074c604bd98d766c7d0a16d30d59a0a02f07564872c6039813dcabf562408a",
	name: "toggleLoanPaid",
	filename: "src/lib/server/finance.ts"
}, (opts) => toggleLoanPaid.__executeServer(opts));
var toggleLoanPaid = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(toggleLoanPaid_createServerFn_handler, async ({ context, data }) => {
	await (await getSql())`
      update loan_payments set paid = not paid
      where id = ${data.id} and user_id = ${context.userId}
    `;
	return { ok: true };
});
var getPlanning_createServerFn_handler = createServerRpc({
	id: "3c5968d5575faeea04bdc86060a2891308d0092857ae9b6497a7bc5fc8606af4",
	name: "getPlanning",
	filename: "src/lib/server/finance.ts"
}, (opts) => getPlanning.__executeServer(opts));
var getPlanning = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getPlanning_createServerFn_handler, async ({ context }) => {
	await ensureSeeded(context.userId);
	const sql = await getSql();
	const goals = await sql`
      select id, name, target_amount, current_amount, deadline::text as deadline, kind
      from goals where user_id = ${context.userId}
    `;
	const costs = await sql`
      select id, expense_name, current_amount, target_amount, status, action_note
      from cost_actions where user_id = ${context.userId} order by current_amount desc
    `;
	const inv = await sql`
      select balance from investments where user_id = ${context.userId} order by month desc limit 1
    `;
	return {
		goals: goals.map((g) => ({
			id: g.id,
			name: g.name,
			target: num(g.target_amount),
			current: g.kind === "emergency" && inv[0] ? num(inv[0].balance) : num(g.current_amount),
			deadline: g.deadline,
			kind: g.kind
		})),
		costs: costs.map((c) => ({
			id: c.id,
			name: c.expense_name,
			current: num(c.current_amount),
			target: num(c.target_amount),
			saving: Math.max(0, num(c.current_amount) - num(c.target_amount)),
			status: c.status,
			note: c.action_note
		}))
	};
});
var setCostStatus_createServerFn_handler = createServerRpc({
	id: "a3e4b2634a15c4313be181feec0f3067d4db0cdddfea75a4a5fd577a77b63421",
	name: "setCostStatus",
	filename: "src/lib/server/finance.ts"
}, (opts) => setCostStatus.__executeServer(opts));
var setCostStatus = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(setCostStatus_createServerFn_handler, async ({ context, data }) => {
	await (await getSql())`
      update cost_actions set status = ${data.status}
      where id = ${data.id} and user_id = ${context.userId}
    `;
	return { ok: true };
});
var askAssistant_createServerFn_handler = createServerRpc({
	id: "b2ba5eadcf192617fd3a108e1b18d7cfd529c6e306ae9a4e06ed8c3ffba28f80",
	name: "askAssistant",
	filename: "src/lib/server/finance.ts"
}, (opts) => askAssistant.__executeServer(opts));
var askAssistant = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(askAssistant_createServerFn_handler, async ({ context, data }) => {
	const question = data.question.trim();
	if (!question) return {
		ok: false,
		error: "Escreva uma pergunta."
	};
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "Assistente indisponível neste ambiente."
	};
	const sql = await getSql();
	const month = currentMonthKey();
	const start = `${month}-01`;
	const next = `${shiftMonth(month, 1)}-01`;
	const snapshot = (await sql`
      select t.description, t.amount, t.direction, t.status, c.name as cat
      from transactions t
      left join categories c on c.id = t.category_id
      where t.user_id = ${context.userId}
        and t.occurred_on >= ${start}::date
        and t.occurred_on < ${next}::date
    `).map((t) => `${t.direction === "in" ? "+" : "-"} ${t.description} (${t.cat ?? "—"}): ${num(t.amount)} [${t.status}]`).join("\n");
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			max_tokens: 400,
			messages: [{
				role: "system",
				content: "Você é o assistente do Bolso360, app de finanças pessoais de uma família brasileira. Responda em português, curto e direto, com valores em R$. Use só os dados fornecidos. Sem enrolação."
			}, {
				role: "user",
				content: `Mês ${month}. Lançamentos:\n${snapshot || "(vazio)"}\n\nPergunta: ${question}`
			}]
		})
	});
	if (!res.ok) return {
		ok: false,
		error: "Não consegui consultar o assistente agora."
	};
	return {
		ok: true,
		text: (await res.json()).choices?.[0]?.message?.content ?? ""
	};
});
//#endregion
export { addContribution_createServerFn_handler, addTransaction_createServerFn_handler, askAssistant_createServerFn_handler, deleteTransaction_createServerFn_handler, getBootstrap_createServerFn_handler, getCards_createServerFn_handler, getInvestments_createServerFn_handler, getLoan_createServerFn_handler, getOverview_createServerFn_handler, getPlanning_createServerFn_handler, listTransactions_createServerFn_handler, setCostStatus_createServerFn_handler, toggleLoanPaid_createServerFn_handler, toggleTransaction_createServerFn_handler, upsertCard_createServerFn_handler };
