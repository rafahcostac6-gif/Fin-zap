import { o as __toESM } from "../_runtime.mjs";
import { s as pct, t as brl } from "./utils-CUk70O1J.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-BB3DMynt.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { C as upsertCard, a as DialogHeader, c as Input, i as DialogContent, l as Label, m as getCards, n as CardContent, o as DialogTitle, r as Dialog, s as GatedPage, t as Card, u as Skeleton } from "./card-CRLWXaoP.mjs";
import { t as Progress } from "./progress-OIb-pYLz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cartoes-Cz-p6a0f.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GatedPage, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cartoes, {}) });
}
function Cartoes() {
	const q = useQuery({
		queryKey: ["cards"],
		queryFn: () => getCards()
	});
	const [open, setOpen] = (0, import_react.useState)(false);
	if (q.isLoading || !q.data) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-36 rounded-xl" })]
	});
	const totalUsed = q.data.cards.reduce((s, c) => s + c.used, 0);
	const totalLimit = q.data.cards.reduce((s, c) => s + c.creditLimit, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-end justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] uppercase tracking-[0.2em] text-muted-foreground",
						children: "Cartões"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-display text-3xl tracking-tight",
						children: "Fatura e limite"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: [
							brl(totalUsed),
							" usados de ",
							brl(totalLimit),
							" neste mês"
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => setOpen(true),
					children: "Novo cartão"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: q.data.cards.map((c) => {
					const usedPct = c.creditLimit > 0 ? c.used / c.creditLimit * 100 : 0;
					const tight = usedPct >= 80;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "pt-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium",
									children: c.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [c.brand, c.holder ? ` · ${c.holder}` : ""]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										"fecha ",
										c.closingDay,
										" · vence ",
										c.dueDay
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 font-display text-2xl tabular-nums tracking-tight",
								children: brl(c.available)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "disponível agora"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
								className: "mt-3",
								value: Math.min(100, usedPct)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex justify-between text-xs text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: tight ? "text-expense" : void 0,
									children: [
										"Fatura ",
										brl(c.used),
										" · ",
										pct(usedPct / 100),
										" do limite"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: brl(c.creditLimit) })]
							})
						]
					}) }, c.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 text-sm font-medium",
				children: "Parcelamentos no radar"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "divide-y divide-border rounded-xl border border-border",
				children: [q.data.parcels.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "px-4 py-6 text-sm text-muted-foreground",
					children: "Nenhum parcelamento marcado."
				}), q.data.parcels.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between px-4 py-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: p.description }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [p.installment, p.cardName ? ` · ${p.cardName}` : ""]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: brl(p.amount)
					})]
				}, p.id))]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardForm, {
				open,
				onOpenChange: setOpen
			})
		]
	});
}
function CardForm({ open, onOpenChange }) {
	const qc = useQueryClient();
	const [name, setName] = (0, import_react.useState)("");
	const [holder, setHolder] = (0, import_react.useState)("");
	const [brand, setBrand] = (0, import_react.useState)("");
	const [limit, setLimit] = (0, import_react.useState)("");
	const [closing, setClosing] = (0, import_react.useState)("20");
	const [due, setDue] = (0, import_react.useState)("10");
	const mut = useMutation({
		mutationFn: () => upsertCard({ data: {
			name,
			holder,
			brand,
			creditLimit: Number(limit.replace(",", ".")),
			closingDay: Number(closing),
			dueDay: Number(due)
		} }),
		onSuccess: () => {
			toast.success("Cartão cadastrado");
			setName("");
			setHolder("");
			setBrand("");
			setLimit("");
			onOpenChange(false);
			qc.invalidateQueries({ queryKey: ["cards"] });
			qc.invalidateQueries({ queryKey: ["bootstrap"] });
		},
		onError: () => toast.error("Não foi possível salvar o cartão")
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Novo cartão" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid gap-3",
			onSubmit: (e) => {
				e.preventDefault();
				mut.mutate();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "grid gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Nome" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						required: true,
						value: name,
						onChange: (e) => setName(e.target.value),
						placeholder: "Neon Iasmim"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Titular" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: holder,
							onChange: (e) => setHolder(e.target.value)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Bandeira" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: brand,
							onChange: (e) => setBrand(e.target.value)
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "grid gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Limite (R$)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						required: true,
						inputMode: "decimal",
						value: limit,
						onChange: (e) => setLimit(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Fecha dia" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							required: true,
							type: "number",
							min: 1,
							max: 28,
							value: closing,
							onChange: (e) => setClosing(e.target.value)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Vence dia" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							required: true,
							type: "number",
							min: 1,
							max: 28,
							value: due,
							onChange: (e) => setDue(e.target.value)
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: mut.isPending,
					children: mut.isPending ? "Salvando…" : "Cadastrar"
				})
			]
		})] })
	});
}
//#endregion
export { Page as component };
