import { o as __toESM } from "../_runtime.mjs";
import { n as cn, r as currentMonthKey, s as pct, t as brl } from "./utils-CUk70O1J.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-BB3DMynt.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { _ as getOverview, b as setCostStatus, f as askAssistant, n as CardContent, s as GatedPage, t as Card, u as Skeleton, v as getPlanning } from "./card-CRLWXaoP.mjs";
import { t as Progress } from "./progress-OIb-pYLz.mjs";
import { t as Badge } from "./badge-CDmV64bQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/planejamento-DpddiaaE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
	className: cn("flex min-h-24 w-full rounded-md border border-input bg-secondary px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/70 focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-50", className),
	ref,
	...props
}));
Textarea.displayName = "Textarea";
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GatedPage, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Planejamento, {}) });
}
function Planejamento() {
	const qc = useQueryClient();
	const plan = useQuery({
		queryKey: ["planning"],
		queryFn: () => getPlanning()
	});
	const overview = useQuery({
		queryKey: ["overview", currentMonthKey()],
		queryFn: () => getOverview({ data: { month: currentMonthKey() } })
	});
	const statusMut = useMutation({
		mutationFn: (input) => setCostStatus({ data: input }),
		onSuccess: () => void qc.invalidateQueries({ queryKey: ["planning"] })
	});
	const [question, setQuestion] = (0, import_react.useState)("Quanto ainda posso investir este mês sem apertar o caixa?");
	const [answer, setAnswer] = (0, import_react.useState)(null);
	const ask = useMutation({
		mutationFn: () => askAssistant({ data: { question } }),
		onSuccess: (res) => {
			if (!res.ok) {
				toast.error(res.error);
				return;
			}
			setAnswer(res.text);
		}
	});
	if (plan.isLoading || !plan.data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64 rounded-xl" });
	const save = plan.data.costs.reduce((s, c) => s + c.saving, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] uppercase tracking-[0.2em] text-muted-foreground",
				children: "Insights"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-3xl tracking-tight",
				children: "O que fazer agora"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium",
					children: "Metas"
				}), plan.data.goals.map((g) => {
					const p = g.target > 0 ? Math.min(100, g.current / g.target * 100) : 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "pt-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium",
									children: g.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs tabular-nums text-muted-foreground",
									children: [
										brl(g.current),
										" / ",
										brl(g.target)
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
								className: "mt-3",
								value: p
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-xs text-muted-foreground",
								children: [
									pct(p / 100),
									" concluída",
									g.deadline ? ` · até ${formatDay(g.deadline)}` : ""
								]
							})
						]
					}) }, g.id);
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-end justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Plano de corte"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							"potencial ",
							brl(save),
							"/mês"
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-border rounded-xl border border-border",
					children: plan.data.costs.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "px-4 py-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm",
								children: c.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted-foreground",
								children: c.note
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm tabular-nums",
									children: [brl(c.current), c.saving > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-income",
										children: [" → ", brl(c.target)]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "mt-1",
									onClick: () => statusMut.mutate({
										id: c.id,
										status: c.status === "ok" ? "pending" : "ok"
									}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: c.status === "ok" ? "income" : c.status === "paying_off" ? "warn" : "outline",
										children: c.status === "ok" ? "Resolvido" : c.status === "paying_off" ? "Quitando" : "Pendente"
									})
								})]
							})]
						})
					}, c.id))
				})]
			}),
			overview.data && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium",
					children: "Motor de análise"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: overview.data.insights.map((ins) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "pt-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-medium",
							children: ins.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm leading-relaxed text-muted-foreground",
							children: ins.body
						})]
					}) }, ins.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "pt-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Pergunte ao assistente"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: "Responde com os lançamentos do mês atual. Uma pergunta por vez."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						className: "mt-3",
						rows: 3,
						value: question,
						onChange: (e) => setQuestion(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-3",
						disabled: ask.isPending,
						onClick: () => ask.mutate(),
						children: ask.isPending ? "Pensando…" : "Perguntar"
					}),
					answer && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 whitespace-pre-wrap text-sm leading-relaxed text-foreground/90",
						children: answer
					})
				]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pb-4 text-xs leading-relaxed text-muted-foreground",
				children: "Open Finance, WhatsApp e Pix por aproximação entram na fase 2. Por enquanto tudo é lançamento manual — o suficiente para substituir a planilha."
			})
		]
	});
}
function formatDay(iso) {
	const [y, m, d] = iso.slice(0, 10).split("-");
	return `${d}/${m}/${y}`;
}
//#endregion
export { Page as component };
