import { o as __toESM } from "../_runtime.mjs";
import { a as monthLabel, s as pct, t as brl } from "./utils-CUk70O1J.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-BB3DMynt.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as Input, d as addContribution, h as getInvestments, l as Label, n as CardContent, s as GatedPage, t as Card, u as Skeleton } from "./card-CRLWXaoP.mjs";
import { t as Progress } from "./progress-OIb-pYLz.mjs";
import { a as XAxis, d as Tooltip, i as YAxis, o as Area, t as AreaChart, u as ResponsiveContainer } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/investimentos-dFr-1kK8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GatedPage, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Investimentos, {}) });
}
function Investimentos() {
	const qc = useQueryClient();
	const q = useQuery({
		queryKey: ["investments"],
		queryFn: () => getInvestments()
	});
	const [amount, setAmount] = (0, import_react.useState)("2000");
	const mut = useMutation({
		mutationFn: () => addContribution({ data: { amount: Number(amount.replace(",", ".")) } }),
		onSuccess: (res) => {
			toast.success(`Saldo atualizado: ${brl(res.balance)}`);
			qc.invalidateQueries({ queryKey: ["investments"] });
			qc.invalidateQueries({ queryKey: ["overview"] });
			qc.invalidateQueries({ queryKey: ["planning"] });
		},
		onError: (e) => toast.error(e.message)
	});
	if (q.isLoading || !q.data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64 rounded-xl" });
	const d = q.data;
	const reservePct = d.emergencyTarget > 0 ? Math.min(100, d.current / d.emergencyTarget * 100) : 0;
	const chart = [...d.history.map((h) => ({
		label: monthLabel(h.month, "short"),
		balance: h.balance,
		kind: "real"
	})), ...d.projection.map((p, i) => ({
		label: `+${p.monthOffset}m`,
		balance: p.balance,
		kind: "proj",
		show: i === 5 || i === 11 || i === 23
	}))];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] uppercase tracking-[0.2em] text-muted-foreground",
					children: "Investimentos"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-3xl tracking-tight",
					children: "Reserva primeiro"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: [
						"CDB / Selic a ",
						pct(d.rate),
						" ao mês. Meta de emergência: ",
						brl(d.emergencyTarget),
						"."
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "pt-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Saldo acumulado"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-4xl tabular-nums tracking-tight",
						children: brl(d.current)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
						className: "mt-4",
						value: reservePct
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-xs text-muted-foreground",
						children: [
							pct(reservePct / 100),
							" da reserva · faltam ",
							brl(Math.max(0, d.emergencyTarget - d.current))
						]
					})
				]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "pt-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-3 text-sm font-medium",
						children: "Projeção em 24 meses (aporte R$ 2.000)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-48",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
								data: chart,
								margin: {
									top: 8,
									right: 8,
									left: 0,
									bottom: 0
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
										id: "inv",
										x1: "0",
										y1: "0",
										x2: "0",
										y2: "1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
											offset: "0%",
											stopColor: "var(--color-income)",
											stopOpacity: .3
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
											offset: "100%",
											stopColor: "var(--color-income)",
											stopOpacity: 0
										})]
									}) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "label",
										hide: true
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, { hide: true }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
										contentStyle: {
											background: "var(--color-popover)",
											border: "1px solid var(--color-border)",
											borderRadius: 12,
											fontSize: 12
										},
										formatter: (v) => brl(Number(v ?? 0))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
										type: "monotone",
										dataKey: "balance",
										stroke: "var(--color-income)",
										fill: "url(#inv)",
										strokeWidth: 1.6
									})
								]
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-xs text-muted-foreground",
						children: [
							"Em 12 meses o saldo estimado chega a ",
							brl(d.projection[11]?.balance ?? 0),
							" · em 24 meses,",
							" ",
							brl(d.projection[23]?.balance ?? 0),
							"."
						]
					})
				]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "pt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium",
					children: "Registrar aporte do mês"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-3 flex gap-2",
					onSubmit: (e) => {
						e.preventDefault();
						mut.mutate();
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid flex-1 gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Valor (R$)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							inputMode: "decimal",
							value: amount,
							onChange: (e) => setAmount(e.target.value)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						className: "mt-5",
						disabled: mut.isPending,
						children: mut.isPending ? "…" : "Aportar"
					})]
				})]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 text-sm font-medium",
					children: "Histórico"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-border rounded-xl border border-border",
					children: d.history.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "grid grid-cols-4 gap-2 px-4 py-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: monthLabel(h.month, "short")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: brl(h.contribution)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums text-income",
								children: brl(h.yieldAmount)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-right tabular-nums font-medium",
								children: brl(h.balance)
							})
						]
					}, h.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 grid grid-cols-4 gap-2 px-4 text-[11px] uppercase tracking-wide text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Mês" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Aporte" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Rend." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-right",
							children: "Saldo"
						})
					]
				})
			] })
		]
	});
}
//#endregion
export { Page as component };
