import { o as __toESM } from "../_runtime.mjs";
import { n as cn, r as currentMonthKey, t as brl } from "./utils-CUk70O1J.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-BB3DMynt.mjs";
import { i as Trash2, p as Check } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { S as toggleTransaction, n as CardContent, p as deleteTransaction, s as GatedPage, t as Card, u as Skeleton, y as listTransactions } from "./card-CRLWXaoP.mjs";
import { t as Badge } from "./badge-CDmV64bQ.mjs";
import { t as MonthSwitcher } from "./month-switcher-B8T6EunJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/lancamentos-CdN0R9G5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GatedPage, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lancamentos, {}) });
}
function Lancamentos() {
	const [month, setMonth] = (0, import_react.useState)(currentMonthKey);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const qc = useQueryClient();
	const q = useQuery({
		queryKey: ["transactions", month],
		queryFn: () => listTransactions({ data: { month } })
	});
	const toggle = useMutation({
		mutationFn: (id) => toggleTransaction({ data: { id } }),
		onSuccess: () => {
			qc.invalidateQueries({ queryKey: ["transactions"] });
			qc.invalidateQueries({ queryKey: ["overview"] });
			qc.invalidateQueries({ queryKey: ["cards"] });
		}
	});
	const remove = useMutation({
		mutationFn: (id) => deleteTransaction({ data: { id } }),
		onSuccess: () => {
			toast.success("Lançamento removido");
			qc.invalidateQueries({ queryKey: ["transactions"] });
			qc.invalidateQueries({ queryKey: ["overview"] });
		},
		onError: () => toast.error("Não foi possível remover")
	});
	const items = (0, import_react.useMemo)(() => {
		const list = q.data?.items ?? [];
		if (filter === "all") return list;
		return list.filter((t) => t.direction === filter);
	}, [q.data, filter]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-end justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] uppercase tracking-[0.2em] text-muted-foreground",
				children: "Lançamentos"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-3xl tracking-tight",
				children: "O mês em linhas"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MonthSwitcher, {
				month,
				onChange: setMonth
			})]
		}), q.isLoading || !q.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40 rounded-xl" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Entradas",
						value: brl(q.data.income)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Saídas",
						value: brl(q.data.expense)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Saldo",
						value: brl(q.data.balance)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2",
				children: [
					"all",
					"out",
					"in"
				].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: filter === f ? "default" : "outline",
					onClick: () => setFilter(f),
					children: f === "all" ? "Todos" : f === "out" ? "Despesas" : "Receitas"
				}, f))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "divide-y divide-border rounded-xl border border-border",
				children: [items.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "px-4 py-8 text-center text-sm text-muted-foreground",
					children: "Nenhum lançamento neste filtro."
				}), items.map((t) => {
					const done = t.status === "paid" || t.status === "received";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3 px-3 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => toggle.mutate(t.id),
								className: cn("grid size-9 shrink-0 place-items-center rounded-full border transition-colors", done ? "border-income/40 bg-income/15 text-income" : "border-border text-muted-foreground"),
								"aria-label": done ? "Desmarcar" : t.direction === "in" ? "Marcar recebido" : "Marcar pago",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: cn("truncate text-sm", done && "text-muted-foreground"),
									children: t.description
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										formatDay(t.occurredOn),
										t.categoryName ? ` · ${t.categoryName}` : "",
										t.installment ? ` · ${t.installment}` : "",
										t.cardName ? ` · ${t.cardName}` : ""
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: cn("text-sm tabular-nums", t.direction === "in" ? "text-income" : "text-foreground"),
									children: [t.direction === "in" ? "+" : "−", brl(t.amount)]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: done ? "income" : "outline",
									className: "mt-1",
									children: t.direction === "in" ? done ? "Recebido" : "A receber" : done ? "Pago" : "Aberto"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon-sm",
								"aria-label": "Excluir",
								onClick: () => remove.mutate(t.id),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4 text-muted-foreground" })
							})
						]
					}, t.id);
				})]
			})
		] })]
	});
}
function Kpi({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
		className: "px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm font-medium tabular-nums",
			children: value
		})]
	}) });
}
function formatDay(iso) {
	const [y, m, d] = iso.slice(0, 10).split("-");
	return `${d}/${m}`;
}
//#endregion
export { Page as component };
