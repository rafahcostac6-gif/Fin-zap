//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CVPaHuIR.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/cartoes",
			"/emprestimo",
			"/investimentos",
			"/lancamentos",
			"/login",
			"/planejamento",
			"/api/auth/$"
		],
		preloads: ["/assets/index-CrtWrSGI.js", "/assets/react-SIfiwpqq.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CrtWrSGI.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Cypn3e4C.js",
			"/assets/card-CN9g-ljT.js",
			"/assets/month-switcher-CA-GD4co.js",
			"/assets/button-DPPf-kBf.js",
			"/assets/progress-B2T0ZXq_.js",
			"/assets/AreaChart-Bo_lvtU3.js",
			"/assets/badge-qegcIe42.js"
		]
	},
	"/cartoes": {
		filePath: "/workspace/src/routes/cartoes.tsx",
		children: void 0,
		preloads: [
			"/assets/cartoes-DypuPmvG.js",
			"/assets/card-CN9g-ljT.js",
			"/assets/button-DPPf-kBf.js",
			"/assets/progress-B2T0ZXq_.js"
		]
	},
	"/emprestimo": {
		filePath: "/workspace/src/routes/emprestimo.tsx",
		children: void 0,
		preloads: [
			"/assets/emprestimo-BVqsPHys.js",
			"/assets/card-CN9g-ljT.js",
			"/assets/button-DPPf-kBf.js",
			"/assets/AreaChart-Bo_lvtU3.js",
			"/assets/badge-qegcIe42.js"
		]
	},
	"/investimentos": {
		filePath: "/workspace/src/routes/investimentos.tsx",
		children: void 0,
		preloads: [
			"/assets/investimentos-BxQNksaG.js",
			"/assets/card-CN9g-ljT.js",
			"/assets/button-DPPf-kBf.js",
			"/assets/progress-B2T0ZXq_.js",
			"/assets/AreaChart-Bo_lvtU3.js"
		]
	},
	"/lancamentos": {
		filePath: "/workspace/src/routes/lancamentos.tsx",
		children: void 0,
		preloads: [
			"/assets/lancamentos-B5nViPyZ.js",
			"/assets/card-CN9g-ljT.js",
			"/assets/month-switcher-CA-GD4co.js",
			"/assets/button-DPPf-kBf.js",
			"/assets/badge-qegcIe42.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-BFzd--V3.js",
			"/assets/client-C85fcJ4s.js",
			"/assets/button-DPPf-kBf.js"
		]
	},
	"/planejamento": {
		filePath: "/workspace/src/routes/planejamento.tsx",
		children: void 0,
		preloads: [
			"/assets/planejamento-7h0KmW2n.js",
			"/assets/card-CN9g-ljT.js",
			"/assets/button-DPPf-kBf.js",
			"/assets/progress-B2T0ZXq_.js",
			"/assets/badge-qegcIe42.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
