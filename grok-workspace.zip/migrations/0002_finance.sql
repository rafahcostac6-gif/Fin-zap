-- Bolso360 household finance schema (per-user)

create table if not exists profiles (
  user_id text primary key,
  display_name text,
  seeded_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists categories (
  id text primary key,
  user_id text not null,
  name text not null,
  kind text not null check (kind in ('income', 'expense')),
  tone text not null default 'muted',
  icon text not null default 'circle',
  unique (user_id, name)
);
create index if not exists categories_user_id_idx on categories (user_id);

create table if not exists cards (
  id text primary key,
  user_id text not null,
  name text not null,
  holder text,
  brand text,
  credit_limit numeric not null default 0,
  closing_day int not null default 20,
  due_day int not null default 10
);
create index if not exists cards_user_id_idx on cards (user_id);

create table if not exists transactions (
  id text primary key,
  user_id text not null,
  occurred_on date not null,
  description text not null,
  amount numeric not null,
  direction text not null check (direction in ('in', 'out')),
  category_id text,
  card_id text,
  installment_label text,
  status text not null default 'pending',
  notes text,
  created_at timestamptz not null default now()
);
create index if not exists transactions_user_month_idx on transactions (user_id, occurred_on);

create table if not exists investments (
  id text primary key,
  user_id text not null,
  month date not null,
  contribution numeric not null default 0,
  yield_amount numeric not null default 0,
  balance numeric not null default 0
);
create unique index if not exists investments_user_month_idx on investments (user_id, month);

create table if not exists loan_payments (
  id text primary key,
  user_id text not null,
  installment int not null,
  due_on date not null,
  opening_balance numeric not null,
  interest_amount numeric not null,
  amortization numeric not null,
  payment numeric not null,
  closing_balance numeric not null,
  paid boolean not null default false
);
create unique index if not exists loan_payments_user_inst_idx on loan_payments (user_id, installment);

create table if not exists goals (
  id text primary key,
  user_id text not null,
  name text not null,
  target_amount numeric not null,
  current_amount numeric not null default 0,
  deadline date,
  kind text not null default 'custom'
);
create index if not exists goals_user_id_idx on goals (user_id);

create table if not exists cost_actions (
  id text primary key,
  user_id text not null,
  expense_name text not null,
  current_amount numeric not null,
  target_amount numeric not null,
  status text not null default 'pending',
  action_note text
);
create index if not exists cost_actions_user_id_idx on cost_actions (user_id);

create table if not exists settings (
  user_id text primary key,
  monthly_yield_rate numeric not null default 0.0115,
  invest_pct numeric not null default 0.20,
  emergency_target numeric not null default 10000,
  loan_principal numeric not null default 13600,
  loan_installment numeric not null default 560,
  loan_cet numeric not null default 0.0243
);
