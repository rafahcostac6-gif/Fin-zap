import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import {
  Area,
  AreaChart,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
} from "recharts";
import { GatedPage } from "@/components/gate";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { getLoan, toggleLoanPaid } from "@/lib/server/finance";
import { brl, cn, pct } from "@/lib/utils";

export const Route = createFileRoute("/emprestimo")({ component: Page });

function Page() {
  return (
    <GatedPage>
      <Emprestimo />
    </GatedPage>
  );
}

function Emprestimo() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["loan"], queryFn: () => getLoan() });
  const [tab, setTab] = useState<"tabela" | "cruzamento">("tabela");

  const toggle = useMutation({
    mutationFn: (id: string) => toggleLoanPaid({ data: { id } }),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["loan"] }),
  });

  if (q.isLoading || !q.data) return <Skeleton className="h-64 rounded-xl" />;
  const d = q.data;

  return (
    <div className="space-y-5">
      <header>
        <p className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Empréstimo LECCA</p>
        <h1 className="mt-1 font-display text-3xl tracking-tight">36 parcelas, sem surpresa</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          CET {pct(d.cet)} a.m. · parcela {brl(d.installment)} · liberação em set/26, 1ª parcela em out/26.
        </p>
      </header>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Kpi label="Saldo devedor" value={brl(d.remainingBalance)} />
        <Kpi label="Parcelas restantes" value={String(d.remainingCount)} />
        <Kpi label="Juros totais" value={brl(d.totalInterest)} />
        <Kpi label="Próxima" value={d.next ? formatDay(d.next.dueOn) : "Quitado"} />
      </div>

      {d.next && (
        <Card>
          <CardContent className="flex items-center justify-between gap-3 pt-5">
            <div>
              <p className="text-xs text-muted-foreground">Parcela {d.next.installment}/36</p>
              <p className="mt-1 font-display text-2xl tabular-nums">{brl(d.next.payment)}</p>
              <p className="text-xs text-muted-foreground">
                {brl(d.next.interest)} de juros · {brl(d.next.amort)} amortiza
              </p>
            </div>
            <Button variant={d.next.paid ? "secondary" : "default"} onClick={() => toggle.mutate(d.next!.id)}>
              {d.next.paid ? "Desmarcar" : "Marcar paga"}
            </Button>
          </CardContent>
        </Card>
      )}

      <div className="flex gap-2">
        <Button size="sm" variant={tab === "tabela" ? "default" : "outline"} onClick={() => setTab("tabela")}>
          Amortização
        </Button>
        <Button
          size="sm"
          variant={tab === "cruzamento" ? "default" : "outline"}
          onClick={() => setTab("cruzamento")}
        >
          Juros × rendimento
        </Button>
      </div>

      {tab === "tabela" ? (
        <>
          <Card>
            <CardContent className="pt-5">
              <div className="h-40">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={d.payments} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                    <XAxis dataKey="installment" tick={{ fill: "var(--color-muted-foreground)", fontSize: 10 }} axisLine={false} tickLine={false} />
                    <Tooltip
                      contentStyle={{
                        background: "var(--color-popover)",
                        border: "1px solid var(--color-border)",
                        borderRadius: 12,
                        fontSize: 12,
                      }}
                      formatter={(v) => brl(Number(v ?? 0))}
                    />
                    <Area dataKey="closing" name="Saldo" stroke="var(--color-chart-2)" fill="var(--color-chart-2)" fillOpacity={0.15} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          <div className="overflow-x-auto rounded-xl border border-border">
            <table className="w-full min-w-[36rem] text-left text-sm">
              <thead className="text-[11px] uppercase tracking-wide text-muted-foreground">
                <tr className="border-b border-border">
                  <th className="px-3 py-2 font-medium">#</th>
                  <th className="px-3 py-2 font-medium">Venc.</th>
                  <th className="px-3 py-2 font-medium">Juros</th>
                  <th className="px-3 py-2 font-medium">Amort.</th>
                  <th className="px-3 py-2 font-medium">Parcela</th>
                  <th className="px-3 py-2 font-medium">Saldo</th>
                </tr>
              </thead>
              <tbody>
                {d.payments.map((p) => (
                  <tr
                    key={p.id}
                    className={cn("border-b border-border/70", p.paid && "text-muted-foreground")}
                  >
                    <td className="px-3 py-2 tabular-nums">{p.installment}</td>
                    <td className="px-3 py-2 tabular-nums">{formatDay(p.dueOn)}</td>
                    <td className="px-3 py-2 tabular-nums">{brl(p.interest)}</td>
                    <td className="px-3 py-2 tabular-nums">{brl(p.amort)}</td>
                    <td className="px-3 py-2 tabular-nums">{brl(p.payment)}</td>
                    <td className="px-3 py-2 tabular-nums">{brl(p.closing)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      ) : (
        <Cruzamento d={d} />
      )}
    </div>
  );
}

function Cruzamento({
  d,
}: {
  d: Awaited<ReturnType<typeof getLoan>>;
}) {
  const c = d.cruzamento;
  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="pt-5">
          <div className="flex flex-wrap items-center gap-2">
            <Badge variant="income">
              Cruza no mês {c.crossMonth ?? "—"}
            </Badge>
            <span className="text-sm text-muted-foreground">
              A partir daí o CDB rende mais do que o juro médio da parcela.
            </span>
          </div>
          <div className="mt-5 h-48">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={c.rows} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                <XAxis dataKey="month" tick={{ fill: "var(--color-muted-foreground)", fontSize: 10 }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    background: "var(--color-popover)",
                    border: "1px solid var(--color-border)",
                    borderRadius: 12,
                    fontSize: 12,
                  }}
                  formatter={(v) => brl(Number(v ?? 0))}
                />
                <Line dataKey="loanInterest" name="Juros empréstimo" stroke="var(--color-expense)" dot={false} strokeWidth={1.6} />
                <Line dataKey="yieldAmount" name="Rendimento" stroke="var(--color-income)" dot={false} strokeWidth={1.6} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
      <div className="grid grid-cols-2 gap-3">
        <Kpi label="Rendimento 36m" value={brl(c.totalYield)} />
        <Kpi label="Juros 36m" value={brl(c.totalLoanInterest)} />
      </div>
      <p className="text-sm leading-relaxed text-muted-foreground">
        No acumulado, o rendimento estimado supera o custo do empréstimo em{" "}
        {brl(c.totalYield - c.totalLoanInterest)}. Isso não apaga o CET alto — a reserva e o
        aporte mensal é que viram o jogo.
      </p>
    </div>
  );
}

function Kpi({ label, value }: { label: string; value: string }) {
  return (
    <Card>
      <CardContent className="px-3 py-3">
        <p className="text-[11px] text-muted-foreground">{label}</p>
        <p className="mt-1 text-sm font-medium tabular-nums">{value}</p>
      </CardContent>
    </Card>
  );
}

function formatDay(iso: string) {
  const [y, m, d] = iso.slice(0, 10).split("-");
  return `${d}/${m}/${y.slice(2)}`;
}
