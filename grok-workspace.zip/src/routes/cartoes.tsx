import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { GatedPage } from "@/components/gate";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { getCards, upsertCard } from "@/lib/server/finance";
import { brl, pct } from "@/lib/utils";

export const Route = createFileRoute("/cartoes")({ component: Page });

function Page() {
  return (
    <GatedPage>
      <Cartoes />
    </GatedPage>
  );
}

function Cartoes() {
  const q = useQuery({ queryKey: ["cards"], queryFn: () => getCards() });
  const [open, setOpen] = useState(false);

  if (q.isLoading || !q.data) {
    return (
      <div className="space-y-3">
        <Skeleton className="h-8 w-40" />
        <Skeleton className="h-36 rounded-xl" />
      </div>
    );
  }

  const totalUsed = q.data.cards.reduce((s, c) => s + c.used, 0);
  const totalLimit = q.data.cards.reduce((s, c) => s + c.creditLimit, 0);

  return (
    <div className="space-y-5">
      <header className="flex items-end justify-between">
        <div>
          <p className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Cartões</p>
          <h1 className="mt-1 font-display text-3xl tracking-tight">Fatura e limite</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            {brl(totalUsed)} usados de {brl(totalLimit)} neste mês
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={() => setOpen(true)}>
          Novo cartão
        </Button>
      </header>

      <div className="grid gap-3 sm:grid-cols-2">
        {q.data.cards.map((c) => {
          const usedPct = c.creditLimit > 0 ? (c.used / c.creditLimit) * 100 : 0;
          const tight = usedPct >= 80;
          return (
            <Card key={c.id}>
              <CardContent className="pt-5">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm font-medium">{c.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {c.brand}
                      {c.holder ? ` · ${c.holder}` : ""}
                    </p>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    fecha {c.closingDay} · vence {c.dueDay}
                  </p>
                </div>
                <p className="mt-5 font-display text-2xl tabular-nums tracking-tight">{brl(c.available)}</p>
                <p className="text-xs text-muted-foreground">disponível agora</p>
                <Progress className="mt-3" value={Math.min(100, usedPct)} />
                <div className="mt-2 flex justify-between text-xs text-muted-foreground">
                  <span className={tight ? "text-expense" : undefined}>
                    Fatura {brl(c.used)} · {pct(usedPct / 100)} do limite
                  </span>
                  <span>{brl(c.creditLimit)}</span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <section>
        <h2 className="mb-3 text-sm font-medium">Parcelamentos no radar</h2>
        <ul className="divide-y divide-border rounded-xl border border-border">
          {q.data.parcels.length === 0 && (
            <li className="px-4 py-6 text-sm text-muted-foreground">Nenhum parcelamento marcado.</li>
          )}
          {q.data.parcels.map((p) => (
            <li key={p.id} className="flex items-center justify-between px-4 py-3 text-sm">
              <div>
                <p>{p.description}</p>
                <p className="text-xs text-muted-foreground">
                  {p.installment}
                  {p.cardName ? ` · ${p.cardName}` : ""}
                </p>
              </div>
              <span className="tabular-nums">{brl(p.amount)}</span>
            </li>
          ))}
        </ul>
      </section>

      <CardForm open={open} onOpenChange={setOpen} />
    </div>
  );
}

function CardForm({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const qc = useQueryClient();
  const [name, setName] = useState("");
  const [holder, setHolder] = useState("");
  const [brand, setBrand] = useState("");
  const [limit, setLimit] = useState("");
  const [closing, setClosing] = useState("20");
  const [due, setDue] = useState("10");

  const mut = useMutation({
    mutationFn: () =>
      upsertCard({
        data: {
          name,
          holder,
          brand,
          creditLimit: Number(limit.replace(",", ".")),
          closingDay: Number(closing),
          dueDay: Number(due),
        },
      }),
    onSuccess: () => {
      toast.success("Cartão cadastrado");
      setName("");
      setHolder("");
      setBrand("");
      setLimit("");
      onOpenChange(false);
      void qc.invalidateQueries({ queryKey: ["cards"] });
      void qc.invalidateQueries({ queryKey: ["bootstrap"] });
    },
    onError: () => toast.error("Não foi possível salvar o cartão"),
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Novo cartão</DialogTitle>
        </DialogHeader>
        <form
          className="grid gap-3"
          onSubmit={(e) => {
            e.preventDefault();
            mut.mutate();
          }}
        >
          <label className="grid gap-1.5">
            <Label>Nome</Label>
            <Input required value={name} onChange={(e) => setName(e.target.value)} placeholder="Neon Iasmim" />
          </label>
          <div className="grid grid-cols-2 gap-3">
            <label className="grid gap-1.5">
              <Label>Titular</Label>
              <Input value={holder} onChange={(e) => setHolder(e.target.value)} />
            </label>
            <label className="grid gap-1.5">
              <Label>Bandeira</Label>
              <Input value={brand} onChange={(e) => setBrand(e.target.value)} />
            </label>
          </div>
          <label className="grid gap-1.5">
            <Label>Limite (R$)</Label>
            <Input required inputMode="decimal" value={limit} onChange={(e) => setLimit(e.target.value)} />
          </label>
          <div className="grid grid-cols-2 gap-3">
            <label className="grid gap-1.5">
              <Label>Fecha dia</Label>
              <Input required type="number" min={1} max={28} value={closing} onChange={(e) => setClosing(e.target.value)} />
            </label>
            <label className="grid gap-1.5">
              <Label>Vence dia</Label>
              <Input required type="number" min={1} max={28} value={due} onChange={(e) => setDue(e.target.value)} />
            </label>
          </div>
          <Button type="submit" disabled={mut.isPending}>
            {mut.isPending ? "Salvando…" : "Cadastrar"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
