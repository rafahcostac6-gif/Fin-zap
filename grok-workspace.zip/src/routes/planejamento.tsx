import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { GatedPage } from "@/components/gate";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { askAssistant, getOverview, getPlanning, setCostStatus } from "@/lib/server/finance";
import { brl, currentMonthKey, pct } from "@/lib/utils";

export const Route = createFileRoute("/planejamento")({ component: Page });

function Page() {
  return (
    <GatedPage>
      <Planejamento />
    </GatedPage>
  );
}

function Planejamento() {
  const qc = useQueryClient();
  const plan = useQuery({ queryKey: ["planning"], queryFn: () => getPlanning() });
  const overview = useQuery({
    queryKey: ["overview", currentMonthKey()],
    queryFn: () => getOverview({ data: { month: currentMonthKey() } }),
  });

  const statusMut = useMutation({
    mutationFn: (input: { id: string; status: string }) => setCostStatus({ data: input }),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["planning"] }),
  });

  const [question, setQuestion] = useState("Quanto ainda posso investir este mês sem apertar o caixa?");
  const [answer, setAnswer] = useState<string | null>(null);
  const ask = useMutation({
    mutationFn: () => askAssistant({ data: { question } }),
    onSuccess: (res) => {
      if (!res.ok) {
        toast.error(res.error);
        return;
      }
      setAnswer(res.text);
    },
  });

  if (plan.isLoading || !plan.data) return <Skeleton className="h-64 rounded-xl" />;

  const save = plan.data.costs.reduce((s, c) => s + c.saving, 0);

  return (
    <div className="space-y-6">
      <header>
        <p className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Insights</p>
        <h1 className="mt-1 font-display text-3xl tracking-tight">O que fazer agora</h1>
      </header>

      <section className="space-y-3">
        <h2 className="text-sm font-medium">Metas</h2>
        {plan.data.goals.map((g) => {
          const p = g.target > 0 ? Math.min(100, (g.current / g.target) * 100) : 0;
          return (
            <Card key={g.id}>
              <CardContent className="pt-5">
                <div className="flex items-baseline justify-between gap-2">
                  <p className="text-sm font-medium">{g.name}</p>
                  <p className="text-xs tabular-nums text-muted-foreground">
                    {brl(g.current)} / {brl(g.target)}
                  </p>
                </div>
                <Progress className="mt-3" value={p} />
                <p className="mt-2 text-xs text-muted-foreground">
                  {pct(p / 100)} concluída
                  {g.deadline ? ` · até ${formatDay(g.deadline)}` : ""}
                </p>
              </CardContent>
            </Card>
          );
        })}
      </section>

      <section className="space-y-3">
        <div className="flex items-end justify-between">
          <h2 className="text-sm font-medium">Plano de corte</h2>
          <p className="text-xs text-muted-foreground">potencial {brl(save)}/mês</p>
        </div>
        <ul className="divide-y divide-border rounded-xl border border-border">
          {plan.data.costs.map((c) => (
            <li key={c.id} className="px-4 py-3">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-sm">{c.name}</p>
                  <p className="mt-1 text-xs text-muted-foreground">{c.note}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm tabular-nums">
                    {brl(c.current)}
                    {c.saving > 0 && (
                      <span className="text-income"> → {brl(c.target)}</span>
                    )}
                  </p>
                  <button
                    type="button"
                    className="mt-1"
                    onClick={() =>
                      statusMut.mutate({
                        id: c.id,
                        status: c.status === "ok" ? "pending" : "ok",
                      })
                    }
                  >
                    <Badge variant={c.status === "ok" ? "income" : c.status === "paying_off" ? "warn" : "outline"}>
                      {c.status === "ok" ? "Resolvido" : c.status === "paying_off" ? "Quitando" : "Pendente"}
                    </Badge>
                  </button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </section>

      {overview.data && (
        <section className="space-y-3">
          <h2 className="text-sm font-medium">Motor de análise</h2>
          <div className="grid gap-3 sm:grid-cols-2">
            {overview.data.insights.map((ins) => (
              <Card key={ins.id}>
                <CardContent className="pt-5">
                  <h3 className="text-sm font-medium">{ins.title}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{ins.body}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      )}

      <Card>
        <CardContent className="pt-5">
          <h2 className="text-sm font-medium">Pergunte ao assistente</h2>
          <p className="mt-1 text-xs text-muted-foreground">
            Responde com os lançamentos do mês atual. Uma pergunta por vez.
          </p>
          <Textarea
            className="mt-3"
            rows={3}
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
          />
          <Button className="mt-3" disabled={ask.isPending} onClick={() => ask.mutate()}>
            {ask.isPending ? "Pensando…" : "Perguntar"}
          </Button>
          {answer && (
            <p className="mt-4 whitespace-pre-wrap text-sm leading-relaxed text-foreground/90">{answer}</p>
          )}
        </CardContent>
      </Card>

      <p className="pb-4 text-xs leading-relaxed text-muted-foreground">
        Open Finance, WhatsApp e Pix por aproximação entram na fase 2. Por enquanto tudo é lançamento
        manual — o suficiente para substituir a planilha.
      </p>
    </div>
  );
}

function formatDay(iso: string) {
  const [y, m, d] = iso.slice(0, 10).split("-");
  return `${d}/${m}/${y}`;
}
