import { useQuery } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import {
  Area,
  AreaChart,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
} from "recharts";
import { ArrowDownRight, ArrowUpRight, ChevronRight } from "lucide-react";
import { GatedPage } from "@/components/gate";
import { MonthSwitcher } from "@/components/month-switcher";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { getOverview } from "@/lib/server/finance";
import { brl, currentMonthKey, monthLabel, pct } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <GatedPage>
      <Dashboard />
    </GatedPage>
  );
}

function Dashboard() {
  const [month, setMonth] = useState(currentMonthKey);
  const q = useQuery({
    queryKey: ["overview", month],
    queryFn: () => getOverview({ data: { month } }),
  });

  if (q.isLoading || !q.data) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-40 w-full rounded-xl" />
        <div className="grid grid-cols-2 gap-3">
          <Skeleton className="h-24 rounded-xl" />
          <Skeleton className="h-24 rounded-xl" />
        </div>
      </div>
    );
  }

  const d = q.data;
  const leftoverPositive = d.leftover >= 0;
  const reservePct = d.emergency ? Math.min(100, (d.emergency.current / d.emergency.target) * 100) : 0;

  return (
    <div className="space-y-6">
      <header className="flex items-end justify-between gap-3">
        <div>
          <p className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Quanto sobra</p>
          <h1 className="mt-1 font-display text-[2.6rem] leading-none tracking-tight tabular-nums sm:text-5xl">
            {brl(d.leftover)}
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            {leftoverPositive ? "até o fim de" : "no vermelho em"} {monthLabel(d.month, "long")}
            {" · "}
            {pct(d.ratio)} da receita
          </p>
        </div>
        <MonthSwitcher month={month} onChange={setMonth} />
      </header>

      <div className="grid grid-cols-2 gap-3">
        <Stat
          label="Receita"
          value={brl(d.income)}
          hint={`${brl(d.received)} já entrou`}
          tone="income"
        />
        <Stat
          label="Despesas"
          value={brl(d.expense)}
          hint={d.pendingOut > 0 ? `${brl(d.pendingOut)} em aberto` : "Tudo marcado"}
          tone="expense"
        />
      </div>

      <Card>
        <CardContent className="pt-5">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-medium">Fluxo nos últimos meses</h2>
            <span className="text-xs text-muted-foreground">entrada vs saída</span>
          </div>
          <div className="h-40">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={d.history} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="inc" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--color-income)" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="var(--color-income)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis
                  dataKey="month"
                  tickFormatter={(v) => monthLabel(String(v), "short").split("/")[0]}
                  tick={{ fill: "var(--color-muted-foreground)", fontSize: 11 }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip
                  contentStyle={{
                    background: "var(--color-popover)",
                    border: "1px solid var(--color-border)",
                    borderRadius: 12,
                    fontSize: 12,
                  }}
                  formatter={(value) => brl(Number(value ?? 0))}
                  labelFormatter={(l) => monthLabel(String(l), "long")}
                />
                <Area
                  type="monotone"
                  dataKey="income"
                  stroke="var(--color-income)"
                  fill="url(#inc)"
                  strokeWidth={1.6}
                  name="Receita"
                />
                <Area
                  type="monotone"
                  dataKey="expense"
                  stroke="var(--color-expense)"
                  fill="none"
                  strokeWidth={1.6}
                  name="Despesa"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-3 lg:grid-cols-[1.2fr_1fr]">
        <Card>
          <CardContent className="pt-5">
            <h2 className="mb-4 text-sm font-medium">Gastos por categoria</h2>
            {d.byCategory.length === 0 ? (
              <p className="text-sm text-muted-foreground">Sem despesas neste mês.</p>
            ) : (
              <div className="flex items-center gap-4">
                <div className="h-36 w-36 shrink-0">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={d.byCategory} dataKey="total" innerRadius={38} outerRadius={58} paddingAngle={2} stroke="none">
                        {d.byCategory.map((c, i) => (
                          <Cell key={c.name} fill={CAT_COLORS[i % CAT_COLORS.length]} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <ul className="min-w-0 flex-1 space-y-2">
                  {d.byCategory.slice(0, 5).map((c, i) => (
                    <li key={c.name} className="flex items-center justify-between gap-2 text-sm">
                      <span className="flex min-w-0 items-center gap-2">
                        <span
                          className="size-2 shrink-0 rounded-full"
                          style={{ background: CAT_COLORS[i % CAT_COLORS.length] }}
                        />
                        <span className="truncate">{c.name}</span>
                      </span>
                      <span className="tabular-nums text-muted-foreground">{brl(c.total)}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardContent className="space-y-4 pt-5">
            <div>
              <div className="flex items-center justify-between text-sm">
                <span>Reserva de emergência</span>
                <span className="tabular-nums text-muted-foreground">
                  {d.emergency ? `${brl(d.emergency.current)} / ${brl(d.emergency.target)}` : "—"}
                </span>
              </div>
              <Progress className="mt-2" value={reservePct} />
              <p className="mt-2 text-xs text-muted-foreground">
                Meta para novembro. CDB com liquidez diária.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <Mini label="Investido" value={brl(d.investmentBalance)} to="/investimentos" />
              <Mini
                label="Próx. parcela"
                value={d.nextLoan ? brl(d.nextLoan.payment) : "Quitado"}
                hint={d.nextLoan ? formatDay(d.nextLoan.due) : undefined}
                to="/emprestimo"
              />
            </div>
            {d.potentialSaving > 0 && (
              <p className="text-xs text-muted-foreground">
                Dá para cortar cerca de {brl(d.potentialSaving)}/mês nas contas fixas.
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-medium">Ainda a pagar</h2>
          <Link to="/lancamentos" className="text-xs text-muted-foreground">
            Ver lançamentos
          </Link>
        </div>
        {d.upcoming.length === 0 ? (
          <p className="text-sm text-muted-foreground">Nada pendente neste mês.</p>
        ) : (
          <ul className="divide-y divide-border rounded-xl border border-border">
            {d.upcoming.map((t) => (
              <li key={t.id} className="flex items-center justify-between gap-3 px-4 py-3">
                <div className="min-w-0">
                  <p className="truncate text-sm">{t.description}</p>
                  <p className="text-xs text-muted-foreground">
                    {formatDay(t.occurredOn)}
                    {t.installment ? ` · ${t.installment}` : ""}
                    {t.categoryName ? ` · ${t.categoryName}` : ""}
                  </p>
                </div>
                <span className="tabular-nums text-sm text-expense">{brl(t.amount)}</span>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-medium">Insights</h2>
          <Link to="/planejamento" className="inline-flex items-center text-xs text-muted-foreground">
            Plano completo <ChevronRight className="size-3" />
          </Link>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          {d.insights.map((ins) => (
            <Card key={ins.id}>
              <CardContent className="pt-5">
                <Badge variant={ins.tone === "ok" ? "income" : ins.tone === "risk" ? "expense" : ins.tone === "warn" ? "warn" : "default"}>
                  {ins.tone === "ok" ? "No rumo" : ins.tone === "risk" ? "Atenção" : ins.tone === "warn" ? "Olhar" : "Nota"}
                </Badge>
                <h3 className="mt-3 text-sm font-medium">{ins.title}</h3>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{ins.body}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </div>
  );
}

const CAT_COLORS = [
  "var(--color-chart-1)",
  "var(--color-chart-2)",
  "var(--color-chart-3)",
  "var(--color-chart-4)",
  "var(--color-chart-5)",
  "var(--color-chart-6)",
];

function Stat({
  label,
  value,
  hint,
  tone,
}: {
  label: string;
  value: string;
  hint: string;
  tone: "income" | "expense";
}) {
  const Icon = tone === "income" ? ArrowUpRight : ArrowDownRight;
  return (
    <Card>
      <CardContent className="pt-4">
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <Icon className={tone === "income" ? "size-3.5 text-income" : "size-3.5 text-expense"} />
          {label}
        </div>
        <p className="mt-2 font-display text-2xl tabular-nums tracking-tight">{value}</p>
        <p className="mt-1 text-xs text-muted-foreground">{hint}</p>
      </CardContent>
    </Card>
  );
}

function Mini({
  label,
  value,
  hint,
  to,
}: {
  label: string;
  value: string;
  hint?: string;
  to: string;
}) {
  return (
    <Link to={to} className="rounded-lg bg-secondary px-3 py-3">
      <p className="text-[11px] text-muted-foreground">{label}</p>
      <p className="mt-1 text-sm font-medium tabular-nums">{value}</p>
      {hint && <p className="text-[11px] text-muted-foreground">{hint}</p>}
    </Link>
  );
}

function formatDay(iso: string) {
  const [y, m, d] = iso.slice(0, 10).split("-");
  return `${d}/${m}/${y}`;
}
