import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { Check, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { GatedPage } from "@/components/gate";
import { MonthSwitcher } from "@/components/month-switcher";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { deleteTransaction, listTransactions, toggleTransaction } from "@/lib/server/finance";
import { brl, currentMonthKey, cn } from "@/lib/utils";

export const Route = createFileRoute("/lancamentos")({ component: Page });

function Page() {
  return (
    <GatedPage>
      <Lancamentos />
    </GatedPage>
  );
}

function Lancamentos() {
  const [month, setMonth] = useState(currentMonthKey);
  const [filter, setFilter] = useState<"all" | "in" | "out">("all");
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["transactions", month],
    queryFn: () => listTransactions({ data: { month } }),
  });

  const toggle = useMutation({
    mutationFn: (id: string) => toggleTransaction({ data: { id } }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["transactions"] });
      void qc.invalidateQueries({ queryKey: ["overview"] });
      void qc.invalidateQueries({ queryKey: ["cards"] });
    },
  });

  const remove = useMutation({
    mutationFn: (id: string) => deleteTransaction({ data: { id } }),
    onSuccess: () => {
      toast.success("Lançamento removido");
      void qc.invalidateQueries({ queryKey: ["transactions"] });
      void qc.invalidateQueries({ queryKey: ["overview"] });
    },
    onError: () => toast.error("Não foi possível remover"),
  });

  const items = useMemo(() => {
    const list = q.data?.items ?? [];
    if (filter === "all") return list;
    return list.filter((t) => t.direction === filter);
  }, [q.data, filter]);

  return (
    <div className="space-y-5">
      <header className="flex items-end justify-between gap-3">
        <div>
          <p className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Lançamentos</p>
          <h1 className="mt-1 font-display text-3xl tracking-tight">O mês em linhas</h1>
        </div>
        <MonthSwitcher month={month} onChange={setMonth} />
      </header>

      {q.isLoading || !q.data ? (
        <Skeleton className="h-40 rounded-xl" />
      ) : (
        <>
          <div className="grid grid-cols-3 gap-2">
            <Kpi label="Entradas" value={brl(q.data.income)} />
            <Kpi label="Saídas" value={brl(q.data.expense)} />
            <Kpi label="Saldo" value={brl(q.data.balance)} />
          </div>
          <div className="flex gap-2">
            {(["all", "out", "in"] as const).map((f) => (
              <Button
                key={f}
                size="sm"
                variant={filter === f ? "default" : "outline"}
                onClick={() => setFilter(f)}
              >
                {f === "all" ? "Todos" : f === "out" ? "Despesas" : "Receitas"}
              </Button>
            ))}
          </div>
          <ul className="divide-y divide-border rounded-xl border border-border">
            {items.length === 0 && (
              <li className="px-4 py-8 text-center text-sm text-muted-foreground">
                Nenhum lançamento neste filtro.
              </li>
            )}
            {items.map((t) => {
              const done = t.status === "paid" || t.status === "received";
              return (
                <li key={t.id} className="flex items-center gap-3 px-3 py-3">
                  <button
                    type="button"
                    onClick={() => toggle.mutate(t.id)}
                    className={cn(
                      "grid size-9 shrink-0 place-items-center rounded-full border transition-colors",
                      done
                        ? "border-income/40 bg-income/15 text-income"
                        : "border-border text-muted-foreground",
                    )}
                    aria-label={done ? "Desmarcar" : t.direction === "in" ? "Marcar recebido" : "Marcar pago"}
                  >
                    <Check className="size-4" />
                  </button>
                  <div className="min-w-0 flex-1">
                    <p className={cn("truncate text-sm", done && "text-muted-foreground")}>{t.description}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatDay(t.occurredOn)}
                      {t.categoryName ? ` · ${t.categoryName}` : ""}
                      {t.installment ? ` · ${t.installment}` : ""}
                      {t.cardName ? ` · ${t.cardName}` : ""}
                    </p>
                  </div>
                  <div className="text-right">
                    <p
                      className={cn(
                        "text-sm tabular-nums",
                        t.direction === "in" ? "text-income" : "text-foreground",
                      )}
                    >
                      {t.direction === "in" ? "+" : "−"}
                      {brl(t.amount)}
                    </p>
                    <Badge variant={done ? "income" : "outline"} className="mt-1">
                      {t.direction === "in" ? (done ? "Recebido" : "A receber") : done ? "Pago" : "Aberto"}
                    </Badge>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon-sm"
                    aria-label="Excluir"
                    onClick={() => remove.mutate(t.id)}
                  >
                    <Trash2 className="size-4 text-muted-foreground" />
                  </Button>
                </li>
              );
            })}
          </ul>
        </>
      )}
    </div>
  );
}

function Kpi({ label, value }: { label: string; value: string }) {
  return (
    <Card>
      <CardContent className="px-3 py-3">
        <p className="text-[11px] text-muted-foreground">{label}</p>
        <p className="mt-1 text-sm font-medium tabular-nums">{value}</p>
      </CardContent>
    </Card>
  );
}

function formatDay(iso: string) {
  const [y, m, d] = iso.slice(0, 10).split("-");
  return `${d}/${m}`;
}
