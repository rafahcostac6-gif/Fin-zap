import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import {
  Area,
  AreaChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { GatedPage } from "@/components/gate";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { addContribution, getInvestments } from "@/lib/server/finance";
import { brl, monthLabel, pct } from "@/lib/utils";

export const Route = createFileRoute("/investimentos")({ component: Page });

function Page() {
  return (
    <GatedPage>
      <Investimentos />
    </GatedPage>
  );
}

function Investimentos() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["investments"], queryFn: () => getInvestments() });
  const [amount, setAmount] = useState("2000");

  const mut = useMutation({
    mutationFn: () => addContribution({ data: { amount: Number(amount.replace(",", ".")) } }),
    onSuccess: (res) => {
      toast.success(`Saldo atualizado: ${brl(res.balance)}`);
      void qc.invalidateQueries({ queryKey: ["investments"] });
      void qc.invalidateQueries({ queryKey: ["overview"] });
      void qc.invalidateQueries({ queryKey: ["planning"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (q.isLoading || !q.data) {
    return <Skeleton className="h-64 rounded-xl" />;
  }

  const d = q.data;
  const reservePct = d.emergencyTarget > 0 ? Math.min(100, (d.current / d.emergencyTarget) * 100) : 0;
  const chart = [
    ...d.history.map((h) => ({ label: monthLabel(h.month, "short"), balance: h.balance, kind: "real" })),
    ...d.projection.map((p, i) => ({
      label: `+${p.monthOffset}m`,
      balance: p.balance,
      kind: "proj",
      show: i === 5 || i === 11 || i === 23,
    })),
  ];

  return (
    <div className="space-y-5">
      <header>
        <p className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Investimentos</p>
        <h1 className="mt-1 font-display text-3xl tracking-tight">Reserva primeiro</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          CDB / Selic a {pct(d.rate)} ao mês. Meta de emergência: {brl(d.emergencyTarget)}.
        </p>
      </header>

      <Card>
        <CardContent className="pt-5">
          <p className="text-xs text-muted-foreground">Saldo acumulado</p>
          <p className="mt-1 font-display text-4xl tabular-nums tracking-tight">{brl(d.current)}</p>
          <Progress className="mt-4" value={reservePct} />
          <p className="mt-2 text-xs text-muted-foreground">
            {pct(reservePct / 100)} da reserva · faltam {brl(Math.max(0, d.emergencyTarget - d.current))}
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="pt-5">
          <h2 className="mb-3 text-sm font-medium">Projeção em 24 meses (aporte R$ 2.000)</h2>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chart} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="inv" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--color-income)" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="var(--color-income)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="label" hide />
                <YAxis hide />
                <Tooltip
                  contentStyle={{
                    background: "var(--color-popover)",
                    border: "1px solid var(--color-border)",
                    borderRadius: 12,
                    fontSize: 12,
                  }}
                  formatter={(v) => brl(Number(v ?? 0))}
                />
                <Area type="monotone" dataKey="balance" stroke="var(--color-income)" fill="url(#inv)" strokeWidth={1.6} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <p className="mt-2 text-xs text-muted-foreground">
            Em 12 meses o saldo estimado chega a {brl(d.projection[11]?.balance ?? 0)} · em 24 meses,{" "}
            {brl(d.projection[23]?.balance ?? 0)}.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="pt-5">
          <h2 className="text-sm font-medium">Registrar aporte do mês</h2>
          <form
            className="mt-3 flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              mut.mutate();
            }}
          >
            <label className="grid flex-1 gap-1.5">
              <Label>Valor (R$)</Label>
              <Input inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} />
            </label>
            <Button type="submit" className="mt-5" disabled={mut.isPending}>
              {mut.isPending ? "…" : "Aportar"}
            </Button>
          </form>
        </CardContent>
      </Card>

      <section>
        <h2 className="mb-3 text-sm font-medium">Histórico</h2>
        <ul className="divide-y divide-border rounded-xl border border-border">
          {d.history.map((h) => (
            <li key={h.id} className="grid grid-cols-4 gap-2 px-4 py-3 text-sm">
              <span className="text-muted-foreground">{monthLabel(h.month, "short")}</span>
              <span className="tabular-nums">{brl(h.contribution)}</span>
              <span className="tabular-nums text-income">{brl(h.yieldAmount)}</span>
              <span className="text-right tabular-nums font-medium">{brl(h.balance)}</span>
            </li>
          ))}
        </ul>
        <div className="mt-2 grid grid-cols-4 gap-2 px-4 text-[11px] uppercase tracking-wide text-muted-foreground">
          <span>Mês</span>
          <span>Aporte</span>
          <span>Rend.</span>
          <span className="text-right">Saldo</span>
        </div>
      </section>
    </div>
  );
}
