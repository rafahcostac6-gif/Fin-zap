import { Link, useRouterState } from "@tanstack/react-router";
import {
  CreditCard,
  Landmark,
  LayoutGrid,
  List,
  Plus,
  TrendingUp,
} from "lucide-react";
import { type ReactNode, useState } from "react";
import { UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { TransactionDialog } from "@/components/transaction-dialog";

const NAV = [
  { to: "/", label: "Início", icon: LayoutGrid },
  { to: "/lancamentos", label: "Gastos", icon: List },
  { to: "/cartoes", label: "Cartões", icon: CreditCard },
  { to: "/investimentos", label: "Investir", icon: TrendingUp },
  { to: "/emprestimo", label: "Dívidas", icon: Landmark },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { isPending } = useCurrentUserState();
  const [open, setOpen] = useState(false);

  return (
    <div className="min-h-dvh bg-background text-foreground">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-56 flex-col border-r border-border bg-background px-4 py-6 lg:flex">
        <Brand />
        <nav className="mt-10 flex flex-1 flex-col gap-1">
          {NAV.map((item) => (
            <NavLink key={item.to} {...item} active={isActive(pathname, item.to)} />
          ))}
          <Link
            to="/planejamento"
            className={cn(
              "mt-4 rounded-md px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground",
              pathname.startsWith("/planejamento") && "bg-secondary text-foreground",
            )}
          >
            Insights e metas
          </Link>
        </nav>
        <div className="border-t border-border pt-4">
          {isPending ? (
            <div className="h-8 w-full animate-pulse rounded-full bg-secondary" />
          ) : (
            <UserButton />
          )}
        </div>
      </aside>

      <header className="sticky top-0 z-20 flex items-center justify-between border-b border-border bg-background/90 px-4 py-3 backdrop-blur lg:hidden">
        <Brand compact />
        {isPending ? (
          <div className="size-8 animate-pulse rounded-full bg-secondary" />
        ) : (
          <div className="scale-90 origin-right">
            <UserButton />
          </div>
        )}
      </header>

      <main className="pb-28 lg:ml-56 lg:pb-10">
        <div className="mx-auto w-full max-w-5xl px-4 pt-5 lg:px-8 lg:pt-8">{children}</div>
      </main>

      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-background/95 pb-[env(safe-area-inset-bottom)] backdrop-blur lg:hidden">
        <ul className="grid grid-cols-5">
          {NAV.map((item) => {
            const Icon = item.icon;
            const active = isActive(pathname, item.to);
            return (
              <li key={item.to}>
                <Link
                  to={item.to}
                  className={cn(
                    "flex min-h-14 flex-col items-center justify-center gap-1 text-[11px] text-muted-foreground",
                    active && "text-foreground",
                  )}
                >
                  <Icon className="size-5" strokeWidth={active ? 2.2 : 1.7} />
                  {item.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      <Button
        size="icon"
        className="fixed bottom-20 right-4 z-40 size-14 rounded-full shadow-lg lg:bottom-8 lg:right-8"
        onClick={() => setOpen(true)}
        aria-label="Novo lançamento"
      >
        <Plus className="size-6" />
      </Button>
      <TransactionDialog open={open} onOpenChange={setOpen} />
    </div>
  );
}

function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <Link to="/" className="flex items-baseline gap-2">
      <span className="font-display text-xl tracking-tight">Bolso360</span>
      {!compact && (
        <span className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
          casa
        </span>
      )}
    </Link>
  );
}

function NavLink({
  to,
  label,
  icon: Icon,
  active,
}: {
  to: string;
  label: string;
  icon: typeof LayoutGrid;
  active: boolean;
}) {
  return (
    <Link
      to={to}
      className={cn(
        "flex items-center gap-3 rounded-md px-3 py-2.5 text-sm text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground",
        active && "bg-secondary text-foreground",
      )}
    >
      <Icon className="size-4" strokeWidth={active ? 2.2 : 1.7} />
      {label}
    </Link>
  );
}

function isActive(pathname: string, to: string) {
  if (to === "/") return pathname === "/";
  return pathname === to || pathname.startsWith(to + "/");
}
