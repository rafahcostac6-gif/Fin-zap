import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState, type ReactNode } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { addTransaction, getBootstrap } from "@/lib/server/finance";
import { currentMonthKey } from "@/lib/utils";

export function TransactionDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const qc = useQueryClient();
  const boot = useQuery({ queryKey: ["bootstrap"], queryFn: () => getBootstrap() });
  const [direction, setDirection] = useState<"out" | "in">("out");
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState("");
  const [occurredOn, setOccurredOn] = useState(() => {
    const n = new Date();
    return `${n.getFullYear()}-${String(n.getMonth() + 1).padStart(2, "0")}-${String(n.getDate()).padStart(2, "0")}`;
  });
  const [categoryId, setCategoryId] = useState("");
  const [cardId, setCardId] = useState("");
  const [installment, setInstallment] = useState("");

  const mutation = useMutation({
    mutationFn: () =>
      addTransaction({
        data: {
          occurredOn,
          description,
          amount: Number(amount.replace(",", ".")),
          direction,
          categoryId: categoryId || null,
          cardId: cardId || null,
          installment: installment || null,
        },
      }),
    onSuccess: async () => {
      toast.success("Lançamento salvo");
      setDescription("");
      setAmount("");
      setInstallment("");
      onOpenChange(false);
      await Promise.all([
        qc.invalidateQueries({ queryKey: ["overview"] }),
        qc.invalidateQueries({ queryKey: ["transactions"] }),
        qc.invalidateQueries({ queryKey: ["cards"] }),
      ]);
    },
    onError: (err: Error) => toast.error(err.message || "Não foi possível salvar"),
  });

  const cats = (boot.data?.categories ?? []).filter((c) =>
    direction === "in" ? c.kind === "income" : c.kind === "expense",
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Novo lançamento</DialogTitle>
          <DialogDescription>
            {currentMonthKey() === occurredOn.slice(0, 7)
              ? "Entra no saldo deste mês."
              : "Vai para o mês da data escolhida."}
          </DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-2">
          <Button
            type="button"
            variant={direction === "out" ? "default" : "outline"}
            onClick={() => {
              setDirection("out");
              setCategoryId("");
            }}
          >
            Despesa
          </Button>
          <Button
            type="button"
            variant={direction === "in" ? "default" : "outline"}
            onClick={() => {
              setDirection("in");
              setCategoryId("");
              setCardId("");
            }}
          >
            Receita
          </Button>
        </div>
        <form
          className="grid gap-3"
          onSubmit={(e) => {
            e.preventDefault();
            mutation.mutate();
          }}
        >
          <Field label="Descrição">
            <Input
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Ex.: Mercado, TIM, adiantamento"
            />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Valor (R$)">
              <Input
                required
                inputMode="decimal"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0,00"
              />
            </Field>
            <Field label="Data">
              <Input type="date" required value={occurredOn} onChange={(e) => setOccurredOn(e.target.value)} />
            </Field>
          </div>
          <Field label="Categoria">
            <Select value={categoryId || undefined} onValueChange={setCategoryId}>
              <SelectTrigger>
                <SelectValue placeholder="Escolher" />
              </SelectTrigger>
              <SelectContent>
                {cats.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          {direction === "out" && (
            <div className="grid grid-cols-2 gap-3">
              <Field label="Cartão">
                <Select value={cardId || undefined} onValueChange={setCardId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Nenhum" />
                  </SelectTrigger>
                  <SelectContent>
                    {boot.data?.cards.map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Parcela">
                <Input value={installment} onChange={(e) => setInstallment(e.target.value)} placeholder="3/12" />
              </Field>
            </div>
          )}
          <Button type="submit" className="mt-2" disabled={mutation.isPending}>
            {mutation.isPending ? "Salvando…" : "Salvar"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="grid gap-1.5">
      <Label>{label}</Label>
      {children}
    </label>
  );
}
